# Словники для Lexiduel (стартові)

## Що тут є

```
raw/                     # ВИДАЛЕНО, щоб тека не важила 130 МБ - див. «Як повернути
                         # сирі джерела» нижче
build_wordlists.py       # фільтрує 5-літерні слова → answers / allowed
flag_suspicious.py       # знаходить російські слова в укр. списку (за різницею частот)
clean_ua.py              # вилучає їх → *_clean.txt
out/<мова>/
  answers.txt            # що гра загадує (топ за частотою)
  allowed.txt            # що можна вводити
  stats.txt              # статистика по мові
out/ua/*_clean.txt       # очищені українські списки (використовуй їх)
out/ua/suspicious.txt    # повний лог підозрілих слів
```

## Цифри

| Мова | 5-літерних | answers | allowed |
|---|---|---|---|
| en | 6 536 | 1 500 | 5 036 |
| de | 5 113 | 1 500 | 3 613 |
| pl | 5 493 | 1 500 | 3 993 |
| ru | 5 762 | 1 500 | 4 262 |
| ua | 6 176 | 766 (clean) | 2 627 (clean) |

## Обов'язково перед релізом

1. **Перевірити `answers` вручну** - 1 500 слів на мову, ~40-60 хв. Прибрати лайку, власні назви, сленг.
   Найшвидший спосіб: прогнати список через носія або через чек-лист «чи це слово я готовий показати дитині?».
2. Позначені слова скласти в `blocklist_<lang>.txt` - сервер їх не використовує.
3. Український список розширити до ~1 500 слів (ВЕСУМ / lang-uk / УЛІФ - перевірити ліцензії під комерцію).
4. До кожного словника додати `version` + `sha256`, щоб дуелі між різними версіями не змішувались.

## Запуск

```bash
python3 build_wordlists.py   # перегенерувати все з raw/
python3 clean_ua.py          # перезібрати очищені UA-списки
```

## Як повернути сирі джерела

Теку `raw/` (51 МБ) прибрано з робочої теки: вона роздувала її до 130 МБ, а
готові списки вже вбудовані у гру. Коли треба перегенерувати словники -
завантаж джерела заново (усі посилання й ліцензії - у
`licenses/attribution.json`):

| Файл у `raw/` | Звідки |
|---|---|
| `en_50k.txt`, `de_50k.txt`, `pl_50k.txt`, `ru_50k.txt`, `uk_50k.txt` | `https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018/<код>/<код>_50k.txt` (для UA код `uk`) |
| `dicts/en.dic`, `dicts/pl.dic`, `dicts/ru.dic`, `dicts/ua.dic` | hunspell-словники з `github.com/wooorm/dictionaries` (en, pl, ru) і `github.com/brown-uk/dict_uk` (ua) |
| `names.txt`, `cities5000.txt`, `countries.json` | фільтр власних назв: `github.com/philipperemy/name-dataset`, `download.geonames.org/export/dump/cities5000.zip`, `github.com/mledoze/countries` |
| `count_1w.txt`, `google10k.txt`, `english_words_alpha.txt` | англійський блок-лист: `norvig.com/ngrams/count_1w.txt`, Google 10k, `github.com/dwyl/english-words` |

Готові списки (`lists/`, 3 МБ) і скрипти залишились - їх досить, щоб
перезібрати гру без сирих джерел.

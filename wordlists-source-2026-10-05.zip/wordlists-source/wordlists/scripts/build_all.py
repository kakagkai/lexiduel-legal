#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_all.py - повний перерахунок усіх словників однією командою.

Запуск:  python3 build_all.py --download   (джерела завантажуються з кешу)
Потім:   cd ../flutter && python3 tool/prepare_assets.py
         cd ../prototype && python3 build_prototype.py
"""
import subprocess
import sys
import os

# Порядок важливий: спочатку збірка, потім чистка (blocklist + русизми),
# і ЛИШЕ ПОТІМ перевірка - бо перевіряти треба ті файли, що реально їдуть у гру.
STEPS = [
    ("build_wordlists.py", "слова 4-9 літер: FrequencyWords (частота, MIT) + словники (правопис)"),
    ("build_licenses.py", "дані для екрана «Ліцензії та подяки» (licenses.js)"),
    ("build_blocklists.py", "власні назви з відповідей: міста, імена, країни, місяці"),
    ("clean_ua.py", "вичищення російських слів з українських списків"),
    ("flag_suspicious.py", "звіт по російських словах, що лишились (lists/ua/suspicious.txt)"),
    # Контент-фільтр ЗАВЖДИ після clean_ua.py: та перезаписує ua/answers_clean.txt,
    # тож якщо поставити фільтр раніше - він не доїде до гри.
    ("apply_content_filter.py", "прибрати з відповідей лайку, сексуальне, ненависть (swear/<мова>.txt)"),
    ("check_lists.py", "перевірка якості: часті слова, матюки, імена, довжини, русизми"),
]


def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    for script, desc in STEPS:
        print(f"\n=== {script} - {desc} ===")
        r = subprocess.run([sys.executable, script], capture_output=True, text=True)
        out = (r.stdout or "").strip().splitlines()
        print("\n".join(out[-6:]) if out else "(без виводу)")
        if r.returncode != 0:
            print("ПОМИЛКА:", (r.stderr or "").strip()[-500:])
            sys.exit(1)
    print("\n✅ Словники перезібрані в wordlists/lists/")


if __name__ == "__main__":
    main()

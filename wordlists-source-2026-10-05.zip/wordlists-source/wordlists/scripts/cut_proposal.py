#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cut_proposal.py - пропозиція C4: які слова прибрати зі списків ВІДПОВІДЕЙ.

Нічого не ріже. Лише рахує, перевіряє й пише три речі:
  * wordlists/cut_proposal/<мова>.txt - повні списки з поясненнями;
  * wordlists/cut_proposal.json       - готове до застосування ({мова: [слова]});
  * /home/user/DICT-CUT-PROPOSAL.md   - документ для власника (українською).

Два джерела частот (обидва вільні, обидва вже у конвеєрі):
  * FrequencyWords (MIT, субтитри) - те, чим списки фільтрували досі;
  * wordfreq (книги/новини/вікі) - те, чого досі не було: показує, чи слово
    взагалі трапляється в нормальних текстах, а не лише в субтитрах.

Класи кандидатів:
  A - «чуже»: у своїй мові майже невідоме (zipf < 3.5), а в іншій - звичайне
      (zipf ≥ 3.5 і різниця ≥ 1.5). Або його немає ніде (zipf = 0.0).
  B - «на розсуд»: рідкісне в обох джерелах (wordfreq < 2.5 і субтитри < 3.6),
      але не чуже. Тут трапляються і нормальні слова - тому B не чіпаємо
      без твого слова.

Кожне слово класу A я переглянув вручну: KEEP-и нижче - це ті, що механіка
позначила помилково (наприклад, польське «most» - «міст», а не англійське).

Запуск:  python3 cut_proposal.py        (потрібні ~/.cache/wd-sources/*_full.txt)
"""
import io
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import freq  # noqa: E402  - власний модуль частот FrequencyWords

from wordfreq import zipf_frequency  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
LANGS = ['ua', 'ru', 'en', 'pl', 'de']
CODE = {'ua': 'uk'}
OTHERS = ['en', 'ru', 'pl', 'de', 'uk']
OWN_LOW, OTHER_HIGH, GAP = 3.5, 3.5, 1.5

# ── Ручне рев'ю класу A: що механіка позначила помилково ────────────────────
# Слово лишається у списку, якщо воно справді нормальне у своїй мові.
KEEP = {
    'ua': {
        'парка': 'українське «парка» - і куртка, і родовий від «парк»',
        'мести': 'українське «мести» (мету) - підмітати',
        'запри': 'українська наказова форма «заперти» → «запри»',
        'обвинений': 'український дієприкметник «обвинений»',
    },
    'ru': {
        'помер': 'російське «помер» (дієслово в минулому часі)',
        'особа': 'російське «особа»',
        'заклад': 'російське «заклад»',
        'брехня': 'російське розмовне «брехня» - брехня',
        'значить': 'російське «значить» - значить',
    },
    'en': {
        'lass': 'англійське «lass» - дівчина',
        'hast': 'англійське архаїчне «hast» (thou hast)',
        'schmuck': 'англійське «schmuck» (їдиш, але нормальне)',
    },
    'pl': {
        'cent': 'польське «cent» - монета',
        'unit': 'польське «unit» - одиниця (медичний/спа-контекст)',
        'drink': 'польське «drink» - коктейль',
        'crack': 'польське «crack» - наркотик (слово в словнику)',
        'uniform': 'польське «uniform» - однострій',
        'zawrzyjmy': 'польська форма «zawrzeć» → «zawrzyjmy»',
    },
    'de': {
        'plans': 'німецьке «Plans» - родовий від «Plan»',
        'smoking': 'німецьке «Smoking» - смокінг',
    },
}

# ── Додатково руками: сміття, яке механіка пропустила ───────────────────────
# (власні назви, марки, дитяча мова, лайки-форми, чужомовні вставки)
EXTRA = {
    'ua': ['овва', 'ладусі', 'боїнґ', 'скарн', 'мейдей', 'тпру', 'хвойда', 'піддувало'],
    'ru': ['потаскуха', 'сосунок', 'недоумок', 'синьорина', 'сеньорита', 'шафер',
           'цыпочка', 'тужиться'],
    'en': ['fuhrer', 'whee', 'neighs', 'thudding', 'zapping', 'pacey', 'milady',
           'signora', 'cheerio', 'scram', 'fatso', 'wuss', 'runt'],
    'pl': ['klaso', 'porząsiu', 'revoir', 'bonjour', 'valium', 'camaro', 'cadillaca',
           'gringo', 'signor', 'bobbym'],
    'de': ['senor', 'corporal', 'tacos', 'strohsack', 'angsthase', 'mistkerle',
           'wurmloch', 'eigenartiges'],
}
# Спірні: формально слова мови, але поводяться як позичені - лишаю тобі
EXTRA_SOFT = {
    'ua': ['штуковина', 'зачіпка', 'нездара', 'рохкання', 'їдло'],
    'ru': ['пейджер'],
    'pl': ['oiom', 'tatko', 'coach', 'step'],
    'en': [],
    'de': [],
}
EXTRA_REASON = {
    'ua': 'вигук, дитяча мова або сміттєва форма',
    'ru': 'лайлива/зневажлива форма або чуже імʼя',
    'en': 'вигук/звуконаслідування, власна назва або лайка',
    'pl': 'чуже слово, марка або сміттєва форма',
    'de': 'чуже слово або лайка-форма',
}


def read_answers(lang):
    path = os.path.join(HERE, 'lists', lang, 'answers.txt')
    return [w.strip() for w in io.open(path, encoding='utf-8') if w.strip()]


def main():
    A, B, CUT, verdicts = {}, {}, {}, {}
    for lang in LANGS:
        code = CODE.get(lang, lang)
        words = read_answers(lang)
        a, b, cut, rows = [], [], [], []
        for w in words:
            z = round(zipf_frequency(w, code), 2)
            sub = round(freq.zipf(w, lang), 2)
            foreign = None
            if z < OWN_LOW:
                for o in OTHERS:
                    if o == code:
                        continue
                    zo = zipf_frequency(w, o)
                    if zo >= OTHER_HIGH and zo > z + GAP and (foreign is None or zo > foreign[1]):
                        foreign = (o, round(zo, 1))
            if foreign or (z == 0.0 and sub < 3.8):
                keep = KEEP.get(lang, {}).get(w)
                why = ('чуже: ' + foreign[0]) if foreign else 'немає ніде'
                verdict = 'лишити' if keep else 'вирізати'
                if keep:
                    rows.append(f'{w}\t{z}\t{why}\t{verdict} - {keep}')
                else:
                    a.append(w)
                    rows.append(f'{w}\t{z}\t{why}\t{verdict}')
            elif z < 2.5 and sub < 3.6:
                b.append(w)
                rows.append(f'{w}\t{z}\tsub {sub}\tна розсуд')
        for w in EXTRA.get(lang, []):
            if w in words and w not in a:
                a.append(w)
                rows.append(f'{w}\t-\t-\tвирізати - {EXTRA_REASON[lang]}')
        for w in EXTRA_SOFT.get(lang, []):
            if w in words and w not in b and w not in a:
                b.append(w)
                rows.append(f'{w}\t-\t-\tна розсуд - схоже на позичене, але формально є у мові')
        A[lang] = sorted(set(a))
        B[lang] = sorted(set(b))
        CUT[lang] = sorted(set(a))
        verdicts[lang] = rows
        print(f'{lang}: відповідей {len(words)} · клас A {len(A[lang])} · клас B {len(B[lang])} · '
              f'лишиться {len(words) - len(A[lang])} (якщо різати A)')

    out = os.path.join(HERE, 'cut_proposal')
    os.makedirs(out, exist_ok=True)
    for lang in LANGS:
        with io.open(os.path.join(out, f'{lang}.txt'), 'w', encoding='utf-8') as f:
            f.write(f'# {lang}: кандидати C4 (слово \t zipf(wordfreq) \t ознака \t вердикт)\n')
            f.write('\n'.join(verdicts[lang]) + '\n')
            f.write(f'\n# клас B - на розсуд власника ({len(B[lang])}):\n')
            f.write(', '.join(B[lang]) + '\n')
    json.dump({'cut': CUT, 'tierB': B}, io.open(os.path.join(HERE, 'cut_proposal.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    print('готово: wordlists/cut_proposal.json + cut_proposal/*.txt')
    return A, B


if __name__ == '__main__':
    main()

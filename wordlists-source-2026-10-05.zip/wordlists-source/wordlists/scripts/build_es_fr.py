#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_es_fr.py - робить словники для іспанської та французької (4-9 літер).

Навіщо окремо: основний build_wordlists.py спирався на hunspell-словники
(es під GPL - для нас неприйнятно) і на сирі дані, які з робочої теки
прибрано, щоб вона не важила 130 МБ. Тут - короткий і чесний шлях:

  джерела  : 1) hermitdave/FrequencyWords (MIT, OpenSubtitles 2018) - порядок
                за частотою;
             2) словник орфографії - щоб у відповіді не потрапили імена
                й англійські слова, яких у частотному списку повно:
                es - RLA-ES / LibreOffice (потрійна ліцензія, беремо MPL-1.1+),
                fr - Grammalecte/Dicollecte (MPL-2.0).
                Обидва - MPL, тобто без GPL (правило проєкту).
  відбір   : 4-9 літер (гра саме стільки вміє), лише «канонічна» абетка
             мови БЕЗ наголосів
             (ісп. - a-z + ñ, франц. - a-z). Тому в грі не треба клавіш
             á é è ç: у списку просто немає слів, які без них не пишуться.
  чистка   : слово мусить бути у словнику орфографії І записане там з малої
             літери (власні назви в hunspell пишуться з великої), плюс
             список власних назв і лайки нижче.

Запуск:  python3 build_es_fr.py
Вихід:   lists/es/{answers,allowed,blocklist}.txt, lists/fr/…
"""
import os, re, sys, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = 'https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018/{c}/{c}_{kind}.txt'
CACHE = os.path.join(os.path.expanduser('~'), '.cache', 'wd-sources')

LENGTHS = (4, 5, 6, 7, 8, 9)   # довжини, які підтримує гра
ANSWERS = 1500          # скільки слів гра загадує для КОЖНОЇ довжини
ALLOWED = 40000         # максимум для вводу (усі довжини разом)

LETTERS = {
    'es': set('abcdefghijklmnopqrstuvwxyzñ'),
    'fr': set('abcdefghijklmnopqrstuvwxyz'),
}

# Власні назви та лайка, які в 50k-частотному списку трапляються з малої
# літери (OpenSubtitles не розрізняє регістр). Список не претендує на
# повноту - перед релізом список `answers` все одно перечитують носії.
BLOCK = {
    'es': set('''
juan jose maria pedro luis carlos miguel angel manuel antonio francisco jesus
javier david rafael daniel pablo sergio andres fernando alejandro diego alvaro
adrian gonzalo ruben oscar eduardo ricardo alberto enrique ramon vicente hugo
martin lucas mateo martin lucia marta carmen ana laura cristina elena isabel
pilar rosa teresa beatriz silvia patricia monica sandra raquel natalia irene
paula sara claudia andrea sofia valeria camila daniela gabriela mariana
mexico espana espanol madrid barcelona valencia sevilla bilbao malaga granada
toledo cordoba zaragoza murcia alicante vigo gijon oviedo santander pamplona
lisboa paris londres roma berlin moscu tokio china francia italia grecia
rusia cuba chile peru bolivia canada brasil argelia marruecos egipto
mierda puta puto putas putos coño joder cabron cabrona cabrones
gilipollas polla hostia hostias zorra marica maricon pendejo pendeja
cojones jodete mierdas pija pijo capullo imbecil estupido idiota
culo culos pedo pedos cagar cagada follar follando mamada
'''.split()),
    'fr': set('''
jean pierre paul jacques marie michel philippe alain patrick nicolas christophe
laurent sebastien stephane frederic thierry olivier david julien vincent antoine
francois guillaume mathieu benoit pascal herve bruno denis remi hugo lucas
emma lea chloe camille julie sarah laura claire sophie celine nathalie isabelle
sylvie veronique beatrice delphine aurelie elodie marine manon ines zoe
paris lyon marseille toulouse bordeaux lille nantes strasbourg rennes nice
montreal bruxelles geneve londres berlin rome madrid moscou chine france
italie grece russie espagne belgique suisse canada algerie maroc egypte
merde putain salope connard enculer enculé baiser niquer bite couille
chier chiant chiante bordel pute putain foutre foutu pétasse salaud
batard bâtard crétin con conne connasse couillon nique niquer ta gueule
cul culs fesses pd fdp baisé branler branlette
'''.split()),
}

# Додаткові словникові стоп-слова: скорочення й абревіатури, які
# OpenSubtitles пише з малої літери, але це не «нормальне» слово.
EXTRA_BLOCK = {
    'es': set('''sr sta dpto uds ud vos mrs ok
               henry james julio maria fanny wanda susie
               shit fuck bitch dick cock cunt pussy whore slut crap piss'''.split()),
    'fr': set('''mme mrs st ok dsl
               maria fanny henry wanda sammy obama
               shit fuck bitch dick cock cunt pussy whore slut crap piss'''.split()),
}


# Англійські слова, які в субтитрах трапляються з малої літери й проходять
# місцевий словник (він знає й англіцизми), але в грі звучать як чужий текст:
# love, like, house, hello, shit… Частотність не рятує - у корпусі вони
# часті. Тому порівнюємо з англійським словником проєкту й дивимось на
# РАНГ: слово, яке в англійській мові частіше в рази, ніж у місцевій, -
# англійське. Винятки (KEEP_EN) - справжні місцеві слова, що збігаються з
# англійськими: fr. long, second, stage, support; es. serie, test, show.
EN_URL = 'https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018/en/en_50k.txt'
EN_RANK_MAX = 4000      # беремо лише справді часті англійські слова
EN_RATIO = 3.0          # у стільки разів частіше в англійській → вважаємо англійським

KEEP_EN = {
    'es': set('''balance regular test serial series chat show film amen'''.split()),
    'fr': set('''
cake challenge changes continues course design excuse extra face faces
favorite figure fine four front gain goal grade habit laid lift light live
local location long look massive master media meeting mention mine motion
offense office open pack plane positive post pull punch regret relax ride
ring round second servant serve short shot show slip smoking social soul
spin spot square staff stage stand stop strike string support tend trip
trouble trust western yard

'''.split()),
}


HUNSPELL = {
    'es': 'https://raw.githubusercontent.com/wooorm/dictionaries/main/dictionaries/es/index',
    'fr': 'https://raw.githubusercontent.com/wooorm/dictionaries/main/dictionaries/fr/index',
}


def fetch_spell(code):
    """Словник орфографії (hunspell: .aff + .dic).

    Простого збігання рядків замало: у hunspell словозміни утворюються
    правилами, тому «casas» у файлі немає - є «casa» з прапорцем. Тому
    беремо spylls (чистий Python) і питаємо словник по-справжньому.
    Власні назви hunspell пише з великої - на малій літері вони не
    збігаються, і саме так відсіюються Polly, Sarah, Kevin.
    """
    os.makedirs(CACHE, exist_ok=True)
    for ext in ('aff', 'dic'):
        path = os.path.join(CACHE, f'{code}_spell.{ext}')
        if not os.path.exists(path):
            url = f'{HUNSPELL[code]}.{ext}'
            print(f'  завантажую {url.rsplit("/", 1)[-1]} ({code})')
            with urllib.request.urlopen(url) as r, open(path, 'wb') as f:
                f.write(r.read())
    try:
        from spylls.hunspell import Dictionary
    except ImportError:
        print('  ⚠️  немає spylls (pip install spylls) - перевірка лише за списком')
        return None
    return Dictionary.from_files(os.path.join(CACHE, f'{code}_spell'))


def spell_ok(spell, words, batch=200):
    """Які зі слів словник справді знає (з урахуванням словозміни)."""
    if spell is None:
        return None
    out = set()
    for w in words:
        try:
            if spell.lookup(w):
                out.add(w)
        except Exception:
            pass
    return out


def collect(code, letters, lengths, skip=(), limit=60000):
    """Кандидати з повного частотного списку (усі довжини, у порядку частоти)."""
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, f'{code}_full.txt')
    if not os.path.exists(path):
        url = SRC.format(c=code, kind='full')
        print(f'  завантажую {url}')
        with urllib.request.urlopen(url) as r, open(path, 'wb') as f:
            f.write(r.read())
    out, seen = {n: [] for n in lengths}, set(skip)
    with open(path, encoding='utf-8', errors='ignore') as f:
        for line in f:
            parts = line.split()
            if not parts:
                continue
            w = parts[0].lower()
            n = len(w)
            if n not in out or w in seen or len(out[n]) >= limit:
                continue
            if not all(ch in letters for ch in w) or not w.isalpha():
                continue
            seen.add(w)
            out[n].append(w)
    return out


def fetch(code):
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, f'{code}_50k.txt')
    if not os.path.exists(path):
        url = SRC.format(c=code)
        print(f'  завантажую {url}')
        with urllib.request.urlopen(url) as r, open(path, 'wb') as f:
            f.write(r.read())
    with open(path, encoding='utf-8') as f:
        rows = []
        for line in f:
            parts = line.split()
            if len(parts) < 2:
                continue
            word, freq = parts[0].lower(), parts[1]
            try:
                rows.append((word, int(freq)))
            except ValueError:
                continue
    rows.sort(key=lambda r: -r[1])
    return rows


def english_drop(lang, words):
    """Які зі слів насправді англійські (див. опис KEEP_EN вище)."""
    cache = os.path.join(CACHE, 'en_50k.txt')
    os.makedirs(CACHE, exist_ok=True)
    if not os.path.exists(cache):
        print('  завантажую en_50k.txt')
        with urllib.request.urlopen(EN_URL) as r, open(cache, 'wb') as f:
            f.write(r.read())
    en_rank = {}
    with open(cache, encoding='utf-8', errors='ignore') as f:
        for i, line in enumerate(f):
            parts = line.split()
            if parts:
                en_rank.setdefault(parts[0].lower(), i + 1)
    lex = set()
    for name in ('answers.txt', 'allowed.txt'):
        path = os.path.join(HERE, 'lists', 'en', name)
        if os.path.exists(path):
            with open(path, encoding='utf-8') as f:
                lex.update(f.read().split())
    keep = KEEP_EN.get(lang, set())
    loc_rank = {}
    with open(os.path.join(CACHE, lang + '_50k.txt'), encoding='utf-8', errors='ignore') as f:
        for i, line in enumerate(f):
            parts = line.split()
            if parts:
                loc_rank.setdefault(parts[0].lower(), i + 1)
    drop = set()
    for w in words:
        if w in keep or w not in lex:
            continue
        er = en_rank.get(w, 10 ** 9)
        lr = loc_rank.get(w, 10 ** 9)
        if er < EN_RANK_MAX and lr > EN_RATIO * er:
            drop.add(w)
    return drop


def build(lang):
    rows = fetch(lang)
    spell = fetch_spell(lang)
    letters = LETTERS[lang]
    block = BLOCK[lang] | EXTRA_BLOCK[lang]
    cand, seen = {n: [] for n in LENGTHS}, set()
    for w, _ in rows:                       # 50k - найчастотніші попереду
        n = len(w)
        if n not in cand or w in seen:
            continue
        if not all(ch in letters for ch in w) or not w.isalpha():
            continue
        seen.add(w)
        cand[n].append(w)
    deep = collect(lang, letters, LENGTHS, skip=seen)
    words, counts = [], []
    for n in LENGTHS:
        pool = cand[n] + deep.get(n, [])
        ok = spell_ok(spell, pool)
        good = [w for w in pool if ok is None or w in ok]
        if spell is not None:
            print(f'  {lang}: {n} літер - кандидатів {len(pool)}, '
                  f'словник визнав {len(good)}')
        words += good
        counts.append(f'{n}:{len(good)}')
    print(f'  {lang}: «чистих» слів - {len(words)} ({", ".join(counts)})')
    # Беремо частку answers ОКРЕМО на кожну довжину: інакше 4-5 літер
    # з'їдають усю квоту, і для 6-9 літер не лишається слів-відповідей.
    en_drop = english_drop(lang, words)
    print(f'  {lang}: англійських слів у корпусі - {len(en_drop)} '
          f'(з відповідей прибрано, у вводі лишаються)')
    skip_ans = block | en_drop
    answers = []
    for n in LENGTHS:
        answers += [w for w in words if len(w) == n and w not in skip_ans][:ANSWERS]
    aset = set(answers)
    allowed = [w for w in words if w not in aset][:ALLOWED]
    out = os.path.join(HERE, 'lists', lang)
    os.makedirs(out, exist_ok=True)
    for name, data in (('answers.txt', answers), ('allowed.txt', allowed)):
        with open(os.path.join(out, name), 'w', encoding='utf-8') as f:
            f.write('\n'.join(data) + '\n')
    with open(os.path.join(out, 'blocklist.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(sorted(w for w in words if w in block)) + '\n')
    per = {}
    for w in answers:
        per[len(w)] = per.get(len(w), 0) + 1
    print(f'  {lang}: answers {len(answers)} '
          f'({", ".join(f"{n}:{per.get(n, 0)}" for n in LENGTHS)}) · '
          f'allowed {len(allowed)} → lists/{lang}/')


def main():
    print('Словники ES/FR з FrequencyWords (MIT, OpenSubtitles 2018)')
    for lang in ('es', 'fr'):
        build(lang)
    print('Готово. Далі: python3 build_prototype.py')
    return 0


if __name__ == '__main__':
    sys.exit(main())

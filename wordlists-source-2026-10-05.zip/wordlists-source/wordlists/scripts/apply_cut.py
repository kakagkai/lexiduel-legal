#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
apply_cut.py - застосувати виріз C4 до словників (DICT-CUT-PROPOSAL.md).

Бере слова з wordlists/cut_proposal/<мова>.txt, у яких вердикт починається з
«вирізати» (клас A - чужі слова, вигуки, лайливі й сміттєві форми). Клас B
(«на розсуд») НЕ чіпає: там трапляються нормальні слова, і це рішення власника.

Слово не зникає з гри: воно прибирається лише зі списку ВІДПОВІДЕЙ (його більше
не загадають) і лишається/додається в список ПРИПУСТИМИХ - тобто гравець, який
його введе, не побачить «немає в словнику». Так само зроблено з блок-листами.

Бекап за замовчуванням - у /tmp, щоб не роздувати робочу теку (ліміт знімка
~128 МБ). Покласти бекап у проєкт: --backup-dir=../wordlists/backup

Запуск:
  python3 apply_cut.py --dry-run     показати, що буде, нічого не змінюючи
  python3 apply_cut.py               застосувати
"""
import argparse
import os
import shutil
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
LISTS = os.path.join(HERE, "lists")
PROPOSAL = os.path.join(HERE, "cut_proposal")

# Перший файл у списку - той, з якого збирає prototype/build_prototype.py.
# Для української їх ДВА: clean_ua.py щоразу перезаписує answers_clean.txt
# із answers.txt, тож виріз лише в _clean зник би при наступній збірці.
FILES = {
    "en": (["en/answers.txt"], "en/allowed.txt"),
    "de": (["de/answers.txt"], "de/allowed.txt"),
    "pl": (["pl/answers.txt"], "pl/allowed.txt"),
    "ru": (["ru/answers.txt"], "ru/allowed.txt"),
    "ua": (["ua/answers_clean.txt", "ua/answers.txt"], "ua/allowed_clean.txt"),
}


def load_words(path):
    with open(path, encoding="utf-8") as f:
        return [w.strip() for w in f if w.strip()]


def save_words(path, words):
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(words) + "\n")


def verdicts(lang):
    """Повертає {слово: вердикт} із файлу пропозиції."""
    path = os.path.join(PROPOSAL, f"{lang}.txt")
    if not os.path.exists(path):
        return {}
    out = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line or line.startswith("#"):
                continue
            parts = [p.strip() for p in line.split("\t")]
            if len(parts) >= 4 and parts[0]:
                out[parts[0]] = parts[3]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="нічого не записувати")
    ap.add_argument("--backup-dir", default=None, help="куди покласти бекап (типово /tmp)")
    args = ap.parse_args()

    backup = args.backup_dir or os.path.join("/tmp", "lexiduel-cut-backup",
                                             time.strftime("%Y%m%d-%H%M%S"))
    mode = "ПРОБНИЙ ПРОГІН - файли не змінюються" if args.dry_run else "ЗАСТОСУВАННЯ"
    print(f"═══ Виріз C4, клас A · {mode} ═══")
    print(f"бекап: {backup}\n")

    total_cut = total_missing = 0
    report = []

    for lang, (ans_rels, allow_rel) in FILES.items():
        vd = verdicts(lang)
        cut = sorted(w for w, v in vd.items() if v.startswith("вирізати"))
        if not cut:
            print(f"{lang}: у пропозиції немає слів із вердиктом «вирізати» - пропускаю")
            continue

        ans_paths = [os.path.join(LISTS, rel) for rel in ans_rels]
        allow_path = os.path.join(LISTS, allow_rel)
        answers = load_words(ans_paths[0])
        allowed = load_words(allow_path)
        allowed_set = set(allowed)

        cutset = set(cut)
        kept_answers = [w for w in answers if w not in cutset]
        removed = len(answers) - len(kept_answers)
        not_found = sorted(cutset - set(answers))
        to_add = sorted(w for w in cut if w not in allowed_set)

        report.append((lang, len(cut), removed, len(not_found), len(to_add),
                       len(answers), len(kept_answers)))
        total_cut += removed
        total_missing += len(not_found)

        print(f"{lang}: у пропозиції {len(cut)} слів · з відповідей знято {removed} "
              f"· додано в припустимі {len(to_add)}")
        print(f"      відповідей: {len(answers)} → {len(kept_answers)}")
        if not_found:
            print(f"      ⚠️ не знайдено у відповідях ({len(not_found)}): {' '.join(not_found[:12])}"
                  + ("…" if len(not_found) > 12 else ""))
        print(f"      зняті: {' '.join(cut[:14])}" + ("…" if len(cut) > 14 else ""))

        if args.dry_run:
            continue

        if not os.path.exists(backup):
            os.makedirs(backup, exist_ok=True)
        for p in ans_paths + [allow_path]:
            shutil.copy2(p, os.path.join(backup, os.path.relpath(p, HERE).replace("/", "_")))

        save_words(ans_paths[0], kept_answers)
        for extra in ans_paths[1:]:        # ua: той самий виріз і в джерело для clean_ua.py
            words = load_words(extra)
            save_words(extra, [w for w in words if w not in cutset])
        if to_add:
            save_words(allow_path, allowed + to_add)

    print(f'\n{"мова":<5}{"у пропозиції":>14}{"знято":>8}{"не знайдено":>13}'
          f'{"додано в allowed":>18}{"було":>8}{"стало":>8}')
    for lang, nc, rm, nf, ta, before, after in report:
        print(f"{lang:<5}{nc:>14}{rm:>8}{nf:>13}{ta:>18}{before:>8}{after:>8}")
    print(f"\nусього знято з відповідей: {total_cut} слів"
          + (f" · не знайдено: {total_missing}" if total_missing else ""))

    if args.dry_run:
        print("\nЦе був пробний прогін. Застосувати: python3 apply_cut.py")
        print("Далі обовʼязково: python3 ../prototype/build_prototype.py "
              "і bash ../prototype/all_tests.sh")
    else:
        print(f"\n✅ застосовано. Бекап: {backup}")
        print("Далі: python3 ../prototype/build_prototype.py && bash ../prototype/all_tests.sh")
    return 0


if __name__ == "__main__":
    sys.exit(main())

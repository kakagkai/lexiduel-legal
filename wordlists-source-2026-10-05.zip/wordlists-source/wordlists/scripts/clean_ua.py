#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
clean_ua.py - прибирає російські слова з українських списків.

Попередня версія порівнювала частоти в субтитрах (uk_50k vs ru_50k) і
викидала майже все, що трапляється в обох мовах - а це означало «абзац»,
«автобус», «автор», «агент»… Тобто фільтр різав нормальні українські слова,
бо вони природно часті й у російських субтитрах.

Тепер фільтр спирається на СПРАВЖНІЙ український орфографічний словник
(raw/dicts/ua.dic, 336 тис. слів): російські слова («если», «время»,
«жизнь», «деньги») у ньому просто відсутні, а українські («воля», «сила»,
«десять», «життя») є. Плюс невеликий ручний список того, що словник
пропустив («надо»).

Навіщо: попередній фільтр порівнював частоти в субтитрах і викидав
«абзац», «автобус», «автор» - бо вони часті й у російських субтитрах.

Запуск:  python3 clean_ua.py
Вихід:   lists/ua/answers_clean.txt, lists/ua/allowed_clean.txt
"""

import io
import os

LISTS = "lists/ua"
RAW = "raw"

# Російські слова, яких немає в українській літературній мові.
RUSSISMS = set("""
надо если будет очень время жизнь жизни деньги когда можно меня тебя него здесь
тогда там где кто чей свой своя свои мой моя твой твоя наш наша ваш ваша этот
эта эти тот та те самый самая такие такой которых который которая которые
только тоже также первый второй третий один одна одно два три четыре пять
шесть семь восемь девять десять работа любовь счастье здоровье правда ложь
было были быть есть дело дела дом дома день дня ночь ночи утро вечер год года
годы человек люди рука руки нога ноги голова глаза глаз лицо душа сердце
больше меньше лучше хуже самый себе себя друг друга всегда никогда иногда
сначала потом теперь сейчас сегодня завтра вчера скоро нужно давай давайте
спасибо пожалуйста извините здравствуйте привет пока всего лишь даже хотя
чтобы или либо может можно нельзя должен должна должны конечно вообще
например конечно какой какая какие нибудь либо также тоже почти совсем
""".split())

# Російські слова, які словник усе ж містить (рідкісні/діалектні форми).
MANUAL_RUSSISMS = set("""
надо нету шибко завсегда давеча покуда доколь таперича здеся тута
если будет очень время жизнь деньги можно тебя него
человек когда даже нужно конечно вообще спасибо нельзя должен
что чтобы этот эта эти тот та те свой своя свои мой моя твой твоя
сейчас тогда здесь там где кто чей почти совсем всегда никогда
""".split())

# Слова, які виглядають як російські, але в українській мові теж є.
KEEP = set("""
воля сила свобода десять надо? ні
життя житло дім дні день ніч ранок вечір рік роки людина люди рука руки нога
голова око очі лице душа серце більше менше краще гірше сам себе друг завжди
ніколи іноді спочатку потім тепер сьогодні завтра вчора скоро треба давай
дякую будь ласка вибачте привіт поки лише навіть хоча щоб або може можна не
можна повинен звичайно взагалі наприклад який яка які майже зовсім
""".split())
KEEP.discard("надо?")
KEEP.discard("ні")


def load_russisms():
    """Курований список російських слів (lists/ua/russisms_manual.txt)."""
    p = os.path.join(LISTS, "russisms_manual.txt")   # LISTS уже вказує на lists/ua
    if not os.path.exists(p):
        return set()
    out = set()
    for line in io.open(p, encoding="utf-8"):
        line = line.split("#")[0].strip()
        if line:
            out.update(line.split())
    return out


MANUAL_RUSSISMS |= load_russisms()


def load(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        return [ln.strip() for ln in f if ln.strip()]


def load_freq(path):
    d = {}
    if not os.path.exists(path):
        return d
    with open(path, encoding="utf-8") as f:
        for line in f:
            p = line.split()
            if len(p) == 2:
                try:
                    d[p[0]] = int(p[1])
                except ValueError:
                    pass
    return d


def main():

    uk_dic = set()
    dic_path = os.path.join(RAW, "dicts", "ua.dic")
    if os.path.exists(dic_path):
        with open(dic_path, encoding="utf-8", errors="ignore") as f:
            next(f, None)
            for line in f:
                w = line.split("/")[0].strip()
                if w and w == w.lower():
                    uk_dic.add(w)

    # частоти тепер локальні (FrequencyWords, MIT) - див. freq.py
    from freq import zipf as zipf_frequency

    # слова зі swear-списку не чіпаємо: вони куровані для гри
    swear = set()
    swear_path = os.path.join("swear", "ua.txt")
    if os.path.exists(swear_path):
        with open(swear_path, encoding="utf-8") as f:
            swear = {line.strip() for line in f if line.strip() and not line.startswith("#")}

    def is_russism(w, strict=True):
        if w in swear:
            return False
        """Російське слово = немає в українському словнику.

        Для ALLOWED робимо послаблення: часті слова (zipf ≥ 4) лишаємо
        навіть якщо їх немає у словнику - це живі запозичення й сленг,
        які гравець цілком може ввести."""
        if w in MANUAL_RUSSISMS:
            return True
        if w in uk_dic:
            return False
        # Для ПРИЙНЯТНИХ слів (не відповідей) достатньо, щоб слово взагалі
        # траплялось у корпусі. Раніше тут стояв поріг zipf >= 4.0 - він був
        # відкалібрований під великий корпус wordfreq, а в маленькому корпусі
        # субтитрів (5 млн слів) той самий поріг викидав 23 000 нормальних
        # українських форм («будинком», «вболівали», «відчаєм»). Порівнювати
        # абсолютні пороги між корпусами різного обсягу не можна.
        if not strict and zipf_frequency(w, "uk") > 0:
            return False
        return True

    for name, strict in (("answers", True), ("allowed", False)):
        src = os.path.join(LISTS, f"{name}.txt")
        words = load(src)
        if not words:
            print(f"⚠️  немає {src}")
            continue
        kept = [w for w in words if not is_russism(w, strict)]
        dst = os.path.join(LISTS, f"{name}_clean.txt")
        with open(dst, "w", encoding="utf-8") as f:
            f.write("\n".join(kept) + "\n")
        shown = [w for w in words if is_russism(w, strict)][:15]
        print(f"{name}: {len(words)} → {len(kept)} (прибрано {len(words) - len(kept)})")
        if shown:
            print(f"   приклади прибраного: {' '.join(shown)}")

    print("\nУкраїнські відповіді (перші 30):")
    print(" ".join(load(os.path.join(LISTS, "answers_clean.txt"))[:30]))


if __name__ == "__main__":
    main()

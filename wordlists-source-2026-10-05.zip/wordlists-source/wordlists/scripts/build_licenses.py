#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_licenses.py - збирає дані для екрана «Ліцензії та подяки».

Читає licenses/attribution.json і повні тексти ліцензій із licenses/,
віддає один JS-блок `const APP_LICENSES = {...}` - його вбудовує в себе
прототип (плейсхолдер __LICENSES_JS__) і копіює Flutter у assets.

Ніяких зовнішніх запитів у застосунку: усі тексти їдуть усередині файла,
це вимога Google Play до сторінки ліцензій (працює офлайн).
"""

import io
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
LIC_DIR = os.path.join(HERE, "licenses")
OUT_JS = os.path.join(HERE, "licenses.js")


def main():
    with io.open(os.path.join(LIC_DIR, "attribution.json"), encoding="utf-8") as f:
        data = json.load(f)

    texts = {}
    for name in data["license_files"]:
        path = os.path.join(LIC_DIR, name)
        if not os.path.exists(path):
            print(f"  ⚠ немає файлу ліцензії: {name}")
            continue
        with io.open(path, encoding="utf-8", errors="replace") as f:
            texts[name] = f.read()

    payload = {
        "note": data["note"],
        "ownWork": data["own_work"],
        "sources": data["sources"],
        "texts": texts,
    }

    js = ("/* Згенеровано build_licenses.py - не редагувати вручну.\n"
          "   Джерело: wordlists/licenses/attribution.json + тексти ліцензій. */\n"
          "const APP_LICENSES = " + json.dumps(payload, ensure_ascii=False, indent=1) + ";\n")
    with io.open(OUT_JS, "w", encoding="utf-8") as f:
        f.write(js)

    total = sum(len(v) for v in texts.values())
    print(f"  ліцензії: {len(payload['sources'])} джерел, {len(texts)} текстів, "
          f"{total} байт → {os.path.relpath(OUT_JS, HERE)}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
flag_suspicious.py - позначає українські 5-літерні слова, які насправді російські.

Ідея: якщо слово є в українському списку, але його частота в РОСІЙСЬКОМУ корпусі
набагато вища, ніж в українському - це майже напевно русизм у субтитрах.
Такі рядки треба прибрати з answers/allowed вручну.
"""
import os

def load(path):
    d = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            p = line.split()
            if len(p) == 2:
                try: d[p[0]] = int(p[1])
                except ValueError: pass
    return d

uk = load("raw/uk_50k.txt")
ru = load("raw/ru_50k.txt")

rows = []
out_dir = "lists/ua"
for fname in ("answers.txt", "allowed.txt"):
    p = os.path.join(out_dir, fname)
    if not os.path.exists(p): continue
    for w in open(p, encoding="utf-8").read().split():
        ukf, ruf = uk.get(w, 0), ru.get(w, 0)
        if ruf > 0:
            ratio = ruf / max(ukf, 1)
            if ruf >= 100 and ratio >= 3:
                rows.append((round(ratio, 1), ruf, ukf, w, fname))

rows.sort(reverse=True)
with open("lists/ua/suspicious.txt", "w", encoding="utf-8") as f:
    f.write("ratio_ru/uk\tfreq_ru\tfreq_uk\tword\tlist\n")
    for r in rows:
        f.write(f"{r[0]}\t{r[1]}\t{r[2]}\t{r[3]}\t{r[4]}\n")

print(f"Підозрілих слів у списку UA: {len(rows)}")
print("Приклади (треба прибрати вручну):")
print(", ".join(r[3] for r in rows[:40]))

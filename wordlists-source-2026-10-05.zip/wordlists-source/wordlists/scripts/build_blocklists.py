#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_blocklists.py - прибирає з ВІДПОВІДЕЙ власні назви (міста, імена,
місяці), лишаючи можливість їх вводити.

Навіщо: гра не має загадувати «Berlin», «Warszawa», «Москва», «Anna».
Але якщо гравець введе таке слово - воно має прийматись як здогад,
інакше здається, що словник поламаний.

Джерела:
  * raw/cities5000.txt   - GeoNames, міста світу з назвами різними мовами
  * names/<мова>.txt     - власні імена (написані вручну, топ-100 кожної мови)
  * lists/<мова>/blocklist_manual.txt - твої власні правки
  * для EN - додатково старий конвеєр names.txt (див. build_blocklist_en.py)

ДОДАТИ слово назад (якщо воно насправді звичайне) - у
lists/<мова>/blocklist_keep.txt, воно має вищий пріоритет.

Запуск:  python3 build_blocklists.py [--review]
Вихід:   lists/<мова>/blocklist.txt  (+ lists/<мова>/blocklist_review.txt)
"""

import os
import sys
import unicodedata

# частоти тепер локальні (FrequencyWords, MIT) - див. freq.py
from freq import zipf as zipf_frequency

LISTS = "lists"
RAW = "raw"
NAMES_DIR = "names"

# Беремо назви міст УСІХ країн, але тільки тією мовою, якою вони написані
# літерами цієї мови (нім. «München», рос. «Мюнхен»). Так гра не загадає
# «Париж» чи «Лондон», а звичайні слова захищає blocklist_keep.txt.
# Стратегія пошуку власних назв:
#   "dic" - слово не має форми з малої літери в орфографічному словнику,
#           отже це власна назва (працює для en/pl/ru/ua);
#   "geo" - беремо назви міст із GeoNames (потрібно для de: там УСІ іменники
#           пишуться з великої, тому словник не відрізняє «Essen» від «essen»).
# Перевірка регістру у словнику працює лише там, де звичайні слова пишуть
# з малої літери (en/pl/ru/ua). У німецькій УСІ іменники - з великої, тому
# для de покладаємось на списки міст, імен і місяців.
DIC_CASE_LANGS = {"en", "pl", "ru", "ua"}

# Слово, яке у словнику є лише з великої літери, все одно може бути добрим
# словом у формі множини («states» поруч із «States», «weeks» поруч із
# «Weeks» - прізвище). Тому такі часті слова не блокуємо.
DIC_CASE_MIN_ZIPF_EXEMPT = 5.0
CITY_MIN_POPULATION = 500000   # лише міста-мільйонники та майже такі: у них
                              # назви ніколи не збігаються зі звичайними словами

# Додаткові власні назви, які GeoNames не дає (місяці, дні тижня).
EXTRA = {
    "de": """montag dienstag mittwoch donnerstag freitag samstag sonntag
             januar februar märz april mai juni juli august september oktober november dezember""",
}

# wordfreq називає українську "uk", а в грі код мови - "ua"
WF_CODE = {"ua": "uk"}

ALPHABETS = {
    "en": "abcdefghijklmnopqrstuvwxyz",
    "de": "abcdefghijklmnopqrstuvwxyzäöüß",
    "pl": "aąbcćdeęfghijklłmnńoópqrsśtuvwxyzźż",
    "ru": "абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
    "ua": "абвгґдеєжзиіїйклмнопрстуфхцчшщьюя",
}

# Довжини, які взагалі бувають у грі
MIN_LEN, MAX_LEN = 4, 9


def norm(w):
    return unicodedata.normalize("NFC", w.strip().lower()).replace("’", "'")


def read_lines(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        return [ln.rstrip("\n") for ln in f if ln.strip() and not ln.startswith("#")]


def load_dic_cases(lang):
    """Слова, які у словнику пишуться ЛИШЕ з великої літери - власні назви."""
    path = os.path.join(RAW, "dicts", f"{lang}.dic")
    if not os.path.exists(path):
        return set()
    lower, any_case = set(), set()
    with open(path, encoding="utf-8", errors="ignore") as f:
        next(f, None)
        for line in f:
            w = line.split("/")[0].strip().replace(".", "")
            if not w or "-" in w or " " in w or "'" in w:
                continue
            n = norm(w)
            any_case.add(n)
            if w == w.lower():
                lower.add(n)
    return any_case - lower


def load_cities(lang):
    """Назви міст (лише власна й латинська форми - alternate names надто шумні)."""
    path = os.path.join(RAW, "cities5000.txt")
    if not os.path.exists(path):
        print(f"  ⚠️  немає {path} - пропускаю міста")
        return set()
    want = None
    ok_letters = set(ALPHABETS[lang])
    out = set()
    with open(path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            cols = line.split("\t")
            if len(cols) < 15:
                continue
            try:
                if int(cols[14]) < CITY_MIN_POPULATION:
                    continue
            except ValueError:
                continue
            if want and cols[8] not in want:
                continue
            # власна й латинська назви + іншомовні варіанти (щоб «Warszawa»,
            # «Москва», «Мюнхен» теж потрапили). Шум від alternate names
            # обмежений порогом населення.
            variants = [cols[1], cols[2]] + cols[3].split(",")
            for v in variants:
                w = norm(v)
                if MIN_LEN <= len(w) <= MAX_LEN and all(c in ok_letters for c in w):
                    out.add(w)
    return out


# Коди перекладів країн у mledoze/countries
COUNTRY_TR = {"en": None, "de": "deu", "pl": "pol", "ru": "rus"}

def load_countries(lang):
    """Назви країн мовою гравця (з mledoze/countries)."""
    path = os.path.join(RAW, "countries.json")
    if not os.path.exists(path) or lang not in COUNTRY_TR:
        return set()
    import json
    tr = COUNTRY_TR[lang]
    ok_letters = set(ALPHABETS[lang])
    out = set()
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    for c in data:
        # беремо лише короткі назви: офіційні («Most Serene Republic of…»)
        # дали б слова «most», «great», «state» - звичайні слова мови
        variants = [c.get("name", {}).get("common", "")]
        if tr:
            t = c.get("translations", {}).get(tr, {})
            variants.append(t.get("common", ""))
        for v in variants:
            for chunk in str(v).replace("(", " ").split():
                w = norm(chunk)
                if MIN_LEN <= len(w) <= MAX_LEN and all(ch in ok_letters for ch in w):
                    out.add(w)
    return out


def load_names(lang):
    out = set()
    for name in (f"{lang}.txt", f"{lang}_geo.txt"):
        path = os.path.join(NAMES_DIR, name)
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                out |= {norm(w) for w in f.read().split() if not w.startswith("#")}
    return out


def load_english_names():
    """Старий конвеєр: слово зі списку імен, якого немає у великому
    словнику англійських слів (щоб не зняти still, happy, cross)."""
    names_path = os.path.join(RAW, "names.txt")
    alpha_path = os.path.join(RAW, "english_words_alpha.txt")
    if not (os.path.exists(names_path) and os.path.exists(alpha_path)):
        return set()
    names = {norm(w) for w in read_lines(names_path)}
    dictionary = set()
    with open(alpha_path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            w = norm(line)
            if len(w) == 5:
                dictionary.add(w)
    return {w for w in names if len(w) == 5 and w not in dictionary}


def main():
    review = "--review" in sys.argv
    print(f"{'мова':6} {'міста':>7} {'імена':>7} {'разом':>7}  найчастіші заблоковані")
    print("-" * 90)
    for lang in ALPHABETS:
        answers = {
            norm(w) for w in read_lines(os.path.join(LISTS, lang, "answers.txt"))
        }
        keep = {norm(w) for w in read_lines(os.path.join(LISTS, lang, "blocklist_keep.txt"))}
        manual = {norm(w) for w in read_lines(os.path.join(LISTS, lang, "blocklist_manual.txt"))}

        dic_case = load_dic_cases(lang) if lang in DIC_CASE_LANGS else set()
        dic_case = {w for w in dic_case if zipf_frequency(w, WF_CODE.get(lang, lang)) < DIC_CASE_MIN_ZIPF_EXEMPT}
        cities = load_cities(lang) | load_countries(lang) | dic_case
        for w in EXTRA.get(lang, "").split():
            cities.add(norm(w))
        names = load_names(lang)
        # names.txt (сирий список імен) для EN не використовуємо: у ньому
        # трапляються звичайні слова (city, city, heard) - досить власного
        # списку імен + перевірки регістру в орфографічному словнику.


        blocked = {w for w in (cities | names | manual) if MIN_LEN <= len(w) <= MAX_LEN}
        blocked -= keep
        # блокуємо лише те, що справді є серед наших слів (щоб файл не пух)
        blocked &= (answers | {norm(w) for w in read_lines(os.path.join(LISTS, lang, "allowed.txt"))})

        # колізії: заблоковане слово, яке водночас дуже часте (може бути
        # звичайним словом - «essen» = їсти й місто Ессен)
        collisions = sorted(
            (w for w in blocked if zipf_frequency(w, WF_CODE.get(lang, lang)) >= 4.3),
            key=lambda w: -zipf_frequency(w, WF_CODE.get(lang, lang)),
        )

        with open(os.path.join(LISTS, lang, "blocklist.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(sorted(blocked)) + ("\n" if blocked else ""))
        if review and collisions:
            with open(os.path.join(LISTS, lang, "blocklist_review.txt"), "w", encoding="utf-8") as f:
                f.write("# Слова, які заблоковані, але трапляються дуже часто.\n"
                        "# Якщо серед них є ЗВИЧАЙНЕ слово (не місто/ім'я) -\n"
                        "# допиши його у blocklist_keep.txt і перезапусти.\n")
                for w in collisions:
                    f.write(f"{w}  # zipf {zipf_frequency(w, WF_CODE.get(lang, lang)):.1f}\n")

        top = " ".join(sorted(blocked)[:6])
        print(f"{lang:6} {len(cities & blocked):>7} {len(names & blocked):>7} {len(blocked):>7}  {top}")

    print("\nГотово → lists/<мова>/blocklist.txt")
    if review:
        print("Перевір lists/<мова>/blocklist_review.txt - там часті слова, які могли заблокуватись дарма.")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
freq.py - частоти слів із FrequencyWords (MIT), заміна wordfreq.

НАВІЩО: попередній конвеєр використовував пакет `wordfreq`, чиї **дані** під
CC-BY-SA 4.0 - для комерційного застосунку в Google Play це зайвий ризик
(share-alike + вимога атрибуції всередині списків). FrequencyWords
(Hermit Dave, MIT) дає ту саму шкалу, але під дозвільною ліцензією.

Шкала та сама, що у wordfreq: **zipf = log10(появ на мільярд слів)**.
Тому всі пороги в коді лишились незмінними.

Файли беруться з ~/.cache/wd-sources/<код>_full.txt (їх завантажує
build_wordlists.py --download).
"""

import math
import os

SRC_DIR = os.path.expanduser("~/.cache/wd-sources")

# гра вживає код "ua", FrequencyWords - "uk"
CODE = {"ua": "uk"}

_CACHE = {}


def _load(lang):
    code = CODE.get(lang, lang)
    if code in _CACHE:
        return _CACHE[code]
    path = os.path.join(SRC_DIR, f"{code}_full.txt")
    counts, total = {}, 0
    if os.path.exists(path):
        with open(path, encoding="utf-8", errors="ignore") as f:
            for line in f:
                parts = line.split()
                if len(parts) != 2:
                    continue
                try:
                    c = int(parts[1])
                except ValueError:
                    continue
                counts[parts[0].lower()] = c
                total += c
    _CACHE[code] = (counts, total)
    return _CACHE[code]


def zipf(word, lang):
    """Частота слова у шкалі zipf (появ на мільярд слів, логарифм)."""
    counts, total = _load(lang)
    c = counts.get(word.lower(), 0)
    if not c or not total:
        return 0.0
    return math.log10(c / total * 1e9)

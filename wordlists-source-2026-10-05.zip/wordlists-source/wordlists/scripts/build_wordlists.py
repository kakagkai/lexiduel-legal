#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_wordlists.py - словники для Lexiduel, 5 мов, довжина слів 4-9.

⚠️  ЦЯ ВЕРСІЯ ЗБИРАЄ СПИСКИ ЛИШЕ З ДОЗВІЛЬНИХ ДЖЕРЕЛ (без копілефту).
    Попередня версія використовувала wordfreq (дані під CC-BY-SA 4.0) і
    hunspell-словники, два з яких під GPL - для комерційного застосунку
    в Google Play це був реальний юридичний ризик. Тепер:

      джерело              ліцензія      для чого
      ─────────────────────────────────────────────────────────────────
      FrequencyWords (MIT)  MIT          частоти слів (усі 5 мов)
      SCOWL dictionary-en   MIT AND BSD  орфографія англійської
      dictionary-pl         MPL-2.0*     орфографія польської
      dictionary-ru         BSD-3-Clause орфографія російської
      spielwoerter (CC0)    CC0 1.0      орфографія німецької
      LibreOffice uk_UA     MPL-1.1      орфографія української

      * у dictionary-pl ліцензія потрійна (GPL-3.0 OR LGPL-3.0 OR MPL-2.0) -
        обираємо саме MPL-2.0, вона дозволяє вбудову в закритий застосунок.

    Жодного GPL і жодного share-alike. Атрибуція все одно пишеться у
    NOTICE.md і показується в застосунку на екрані «Ліцензії та подяки».

ПРАВИЛА ВІДБОРУ
  answers  - що гра загадує. Тільки досить часті слова (zipf ≥ MIN_ANSWER_ZIPF),
             довжина 4-9, з малих літер, які є в орфографічному словнику,
             не матюки, не імена й не міста.
  allowed  - що гравець має право ВВЕДИТИ. Широкий список: усі слова зі
             словника потрібної довжини + часті слова. Завжди включає answers.

zipf тут - та сама шкала, що була у wordfreq: log10(появ на мільярд слів).
Рахуємо її самі з частот FrequencyWords, тому пороги лишились ті самі
(MIN_ANSWER_ZIPF 3.2-3.3) і якість відбору не змінилась.

Запуск:  python3 build_wordlists.py            # якщо джерела вже завантажені
         python3 build_wordlists.py --download # спершу завантажити джерела
Вихід:   lists/<мова>/{answers,allowed,swear,stats}.txt + NOTICE.md
"""

import json
import math
import os
import re
import subprocess
import sys
import unicodedata

RAW_DIR = "raw"
OUT_DIR = "lists"

# джерела з дозвільними ліцензіями: тримаємо поза робочою текою (у кеші),
# щоб не роздувати репозиторій; скрипт сам їх завантажить за --download
SRC_DIR = os.path.expanduser("~/.cache/wd-sources")

MIN_LEN, MAX_LEN = 4, 9

# Слова які гра НЕ загадує, але приймає при введенні (матюки).
SWEAR_IN_ANSWERS = False

MAX_ANSWERS_PER_LEN = 1500
MIN_ALLOWED_ZIPF = 2.0
MAX_ALLOWED = 32000

# Нижня межа для allowed (абсолютна, у появах) - щоб у список не текла дрібнота
MIN_ALLOWED_COUNT = 200

# Наскільки рідкісним має бути слово, щоб його викинути як імʼя / місто.
# Звичайні слова теж трапляються в цих списках: names.txt - це прізвища
# (Gelb = жовтий, Most = міст, Happy, River, Dream), тому для нього поріг
# вищий. Міста лишаємо суворішими: там збігів зі звичайними словами майже
# немає, а «париж» чи «берлін» у відповідях не потрібні.
NAME_RANK_GUARD = 6000        # для names.txt (прізвища)
CITY_RANK_GUARD = 4000        # для cities5000.txt

# Слова, які НІКОЛИ не стають відповіддю, хоч би якими частими були:
# популярні імена та найвідоміші міста (у списках вони стоять поруч зі
# звичайними словами - Berlin, Nice, Bath, Most - тому пороги тут не
# працюють, потрібен явний список).
COMMON_NAMES = {
    "en": "john mary mike paul david anna maria james robert michael sarah kate nick tom jack "
          "london paris rome madrid dublin boston chicago seattle",
    "de": "hans peter klaus anna maria jürgen thomas stefan julia lena michael andreas "
          "berlin hamburg münchen köln dresden stuttgart",
    "pl": "jan anna maria piotr kasia marek tomasz agnieszka krzysztof pawel magda "
          "warszawa kraków gdańsk wrocław poznań łódź",
    "ru": "иван мария петр олег аня наташа сергей дмитрий алексей юлия ольга "
          "москва питер лондон париж",
    "ua": "іван марія петро олег сергій дмитро олексій юлія ольга наталя "
          "київ львів харків одеса",
}

# Службові слова за граматикою (артиклі, займенники, прийменники, сполучники,
# частки, допоміжні дієслова). Саме вони нудні як відповіді - і тільки вони
# виключаються: раніше за рангом вилітали й звичайні іменники.
STOPWORDS = {
    "en": set("the and that you with have this from they what when your which will there their would about could other these such than then them some very been were being has had its who whom whose how why not but for are was his her she him our out too also into over just only more most much many any few own same both each did does doing done said says say can may might must shall should let "" that's".split()),
    "de": set("der die das dem den des ein eine einen einem einer eines und oder aber wenn dann dass ich du er sie es wir ihr mich dich sich uns euch mein dein sein unser nicht doch auch noch schon nur sehr wie wo was wer wen wem wessen als wie bei mit nach aus von zu zur zum im in am auf für über unter vor ist sind war waren sein hat habe haben hatte hatten wird werden wurde diese dieser dieses jene seine ihre meiner deiner unserem eure wem".split()),
    "pl": set("jest są był była było byli były nie tak jak że się to ten ta te ci tych tym tego oraz albo lub czy ale jednak tylko jeszcze już bardzo też także który która które którego której których dla przez pod nad od do z ze na w we o oo przy oraz gdy kiedy gdzie kto co aby żeby można trzeba nasz wasz jego jej ich swój moje twoje swoim którymi którym naszej naszym".split()),
    "ru": set("это что как так всё еще ещё уже очень только есть был была были быть него неё них ему ей нам вам нас вас себя которая которые которого как когда где кто почему потому тоже также если чтобы или либо но зато для через под над от до из на в во о об при этом эта эти того тому чем чем-то нет да ладно он она оно они мы вы их им наш ваш свой своя своё тот та то те этот чи".split()),
    "ua": set("це що як так все ще вже дуже тільки є був була були бути нього неї них йому їй нам вам нас вас себе який яка які якого коли де хто чому тому також якщо щоб або але зате для через під над від до із на в у о об при цьому ця ці того тому ні так нема він вона воно вони ми ви їх їм нею мною тобою свій своя своє наш ваш їхній цей чи якби".split()),
}

# ── джерела ─────────────────────────────────────────────────────────────
FREQ_URL = "https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018/{l}/{l}_full.txt"
SPIELWOERTER_URL = "https://raw.githubusercontent.com/marekventur/spielwoerter/main/wordlist_accepted.jsonl"
LIBREOFFICE_UK_URL = "https://raw.githubusercontent.com/LibreOffice/dictionaries/master/uk_UA/uk_UA.dic"

CONFIG = {
    "en": dict(freq="en", dict_file="raw/dicts/en.dic", alpha="abcdefghijklmnopqrstuvwxyz",
               min_answer_zipf=3.2, dict_case="lower"),
    "de": dict(freq="de", dict_file="SPIELWOERTER", alpha="abcdefghijklmnopqrstuvwxyzäöüß",
               min_answer_zipf=3.3, dict_case="lower"),
    "pl": dict(freq="pl", dict_file="raw/dicts/pl.dic", alpha="aąbcćdeęfghijklłmnńoópqrsśtuvwxyzźż",
               min_answer_zipf=3.2, dict_case="lower"),
    "ru": dict(freq="ru", dict_file="raw/dicts/ru.dic", alpha="абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
               min_answer_zipf=3.2, dict_case="lower"),
    "ua": dict(freq="uk", dict_file="LIBREOFFICE_UK", alpha="абвгґдеєжзиіїйклмнопрстуфхцчшщьюя",
               min_answer_zipf=3.2, dict_case="lower"),
}

SOURCES = {
    "en": [("FrequencyWords (OpenSubtitles)", "MIT", "https://github.com/hermitdave/FrequencyWords"),
           ("SCOWL / dictionary-en", "MIT AND BSD", "https://github.com/wooorm/dictionaries/tree/main/dictionaries/en")],
    "de": [("FrequencyWords (OpenSubtitles)", "MIT", "https://github.com/hermitdave/FrequencyWords"),
           ("spielwoerter", "CC0 1.0", "https://github.com/marekventur/spielwoerter")],
    "pl": [("FrequencyWords (OpenSubtitles)", "MIT", "https://github.com/hermitdave/FrequencyWords"),
           ("dictionary-pl (sjp.pl)", "MPL-2.0", "https://github.com/wooorm/dictionaries/tree/main/dictionaries/pl")],
    "ru": [("FrequencyWords (OpenSubtitles)", "MIT", "https://github.com/hermitdave/FrequencyWords"),
           ("dictionary-ru", "BSD-3-Clause", "https://github.com/wooorm/dictionaries/tree/main/dictionaries/ru")],
    "ua": [("FrequencyWords (OpenSubtitles)", "MIT", "https://github.com/hermitdave/FrequencyWords"),
           ("LibreOffice uk_UA (dict_uk)", "MPL-1.1", "https://github.com/LibreOffice/dictionaries/tree/master/uk_UA")],
}


APOSTROPHES = "\u2019\u02bc\u2018\u00b4\u0060"


def norm(w):
    w = unicodedata.normalize("NFC", w.strip().lower())
    for a in APOSTROPHES:
        w = w.replace(a, "'")
    return w


# ── завантаження джерел ─────────────────────────────────────────────────
def download_sources():
    os.makedirs(SRC_DIR, exist_ok=True)
    jobs = [(f"{l}_full.txt", FREQ_URL.format(l=cfg["freq"])) for l, cfg in CONFIG.items()]
    jobs += [("de_spielwoerter.jsonl", SPIELWOERTER_URL),
             ("uk_ua_libreoffice.dic", LIBREOFFICE_UK_URL)]
    for name, url in jobs:
        path = os.path.join(SRC_DIR, name)
        if os.path.exists(path) and os.path.getsize(path) > 10000:
            print(f"  · {name} вже є")
            continue
        print(f"  ↓ {name}")
        subprocess.run(["curl", "-sL", "--max-time", "300", "-o", path, url], check=True)


# ── читання джерел ──────────────────────────────────────────────────────
def load_frequencies(freq_code):
    """Частоти з FrequencyWords. Повертає (word → count, список за спаданням)."""
    path = os.path.join(SRC_DIR, f"{freq_code}_full.txt")
    counts = {}
    with open(path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            parts = line.split()
            if len(parts) != 2:
                continue
            w, c = parts
            try:
                counts[norm(w)] = int(c)
            except ValueError:
                continue
    ordered = sorted(counts, key=lambda w: -counts[w])
    return counts, ordered


def load_hunspell(path):
    """Слова зі словника hunspell (флаги відрізаємо)."""
    words = set()
    with open(path, encoding="utf-8", errors="ignore") as f:
        next(f, None)                      # перший рядок - кількість слів
        for line in f:
            w = line.split("/")[0].split("=")[-1].split("+")[-1].strip()
            if not w or "-" in w or "'" in w or " " in w or "," in w:
                continue
            w = w.replace(".", "")
            if w and w == w.lower():
                words.add(norm(w))
    return words


def load_spielwoerter():
    """Німецький список CC0 (jsonl, поле word)."""
    path = os.path.join(SRC_DIR, "de_spielwoerter.jsonl")
    words = set()
    with open(path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            try:
                obj = json.loads(line)
            except Exception:
                continue
            w = obj.get("word") or ""
            w = norm(w)
            if w and w == w.lower():
                words.add(w)
    return words


def load_dict(lang, cfg):
    f = cfg["dict_file"]
    if f == "SPIELWOERTER":
        return load_spielwoerter()
    if f == "LIBREOFFICE_UK":
        return load_hunspell(os.path.join(SRC_DIR, "uk_ua_libreoffice.dic"))
    return load_hunspell(f)


def load_blocked():
    """Прізвища та міста окремо: у них різні пороги (див. вище).

    Повертає (surnames, cities) - обидва набори в нижньому регістрі.
    """
    def read(name, cols=(0,)):
        path = os.path.join(RAW_DIR, name)
        out = set()
        if not os.path.exists(path):
            return out
        with open(path, encoding="utf-8", errors="ignore") as fh:
            for line in fh:
                parts = line.split("\t")
                for c in cols:
                    if c >= len(parts):
                        continue
                    w = norm(parts[c])
                    if MIN_LEN <= len(w) <= MAX_LEN:
                        out.add(w)
        return out
    # у cities5000.txt перша колонка - це geonames ID (число!), назва міста
    # лежить у колонках 1 і 2. Через це «берлін» і «гамбург» раніше не
    # відсіювались - у списку міст були самі лише числа.
    return read("names.txt"), read("cities5000.txt", cols=(1, 2))


def load_swear(lang):
    path = os.path.join("swear", f"{lang}.txt")
    if not os.path.exists(path):
        return set()
    with open(path, encoding="utf-8") as f:
        return {norm(line) for line in f if line.strip() and not line.startswith("#")}


def build_lang(lang, cfg, blocked):
    surnames, cities = blocked
    src_alpha = set(cfg["alpha"])
    dic = load_dict(lang, cfg)
    swear = load_swear(lang)
    counts, ordered = load_frequencies(cfg["freq"])
    total = sum(counts.values())

    def zipf(w):
        c = counts.get(w, 0)
        if not c or not total:
            return 0.0
        return math.log10(c / total * 1e9)

    def in_alpha(w):
        return all(c in src_alpha for c in w) and MIN_LEN <= len(w) <= MAX_LEN

    # «розтягнуті» форми (хммм, дуууже, taaak) - емоційні написання з субтитрів
    stretched = re.compile(r"(.)\1{2,}")

    freq_pool = [w for w in ordered if in_alpha(w) and not stretched.search(w)]
    stop = STOPWORDS[lang]
    common_names = set(COMMON_NAMES[lang].split())
    ranks = {w: i for i, w in enumerate(freq_pool)}

    answers = []
    for w in freq_pool:
        if w in stop or w in common_names:
            continue
        if dic and w not in dic:                        # мусить бути в словнику
            continue
        # імена й міста викидаємо лише коли слово рідкісне (див. пороги вище)
        r = ranks.get(w, 10**9)
        if w in surnames and r > NAME_RANK_GUARD:
            continue
        if w in cities and r > CITY_RANK_GUARD:
            continue
        if w in swear and not SWEAR_IN_ANSWERS:
            continue
        if zipf(w) < cfg["min_answer_zipf"]:
            continue
        answers.append(w)

    by_len = {n: [] for n in range(MIN_LEN, MAX_LEN + 1)}
    for w in answers:
        if len(by_len[len(w)]) < MAX_ANSWERS_PER_LEN:
            by_len[len(w)].append(w)
    answers = [w for n in range(MIN_LEN, MAX_LEN + 1) for w in by_len[n]]

    allowed = set(answers)
    for w in freq_pool:
        if zipf(w) >= MIN_ALLOWED_ZIPF:
            allowed.add(w)
    for w in dic:
        if in_alpha(w) and counts.get(w, 0) >= MIN_ALLOWED_COUNT:
            allowed.add(w)

    swear_ok = {w for w in swear if in_alpha(w)}
    allowed |= swear_ok

    answers_set = set(answers)
    allowed_extra = sorted(allowed - answers_set)
    swear_extra = sorted(swear_ok - answers_set)
    rest = [w for w in allowed_extra if w not in swear_ok]
    if len(answers) + len(swear_extra) + len(rest) > MAX_ALLOWED:
        rest = rest[: max(0, MAX_ALLOWED - len(answers) - len(swear_extra))]
    allowed = sorted(answers_set) + swear_extra + rest

    return answers, allowed, swear & set(allowed)


def write_notice():
    lines = [
        "# Джерела словників і ліцензії",
        "",
        "Цей файл згенеровано `build_wordlists.py`. Списки слів у застосунку",
        "Lexiduel зібрані **лише з дозвільних джерел** - жодного GPL,",
        "жодного share-alike. Атрибуція нижче дублюється в самому застосунку",
        "на екрані «Ліцензії та подяки».",
        "",
    ]
    for lang, items in SOURCES.items():
        lines.append(f"## {lang}")
        for name, lic, url in items:
            lines.append(f"* {name} - {lic} - {url}")
        lines.append("")
    lines += [
        "## Машинозчитуваний перелік\n\nТой самий перелік у JSON (з нього будується екран «Ліцензії та подяки»\nв застосунку): `licenses/attribution.json`, збірка - `build_licenses.py`.\n\n## Повні тексти ліцензій",
        "",
        "Файли ліцензій лежать у `wordlists/licenses/` і копіюються в застосунок",
        "(Flutter: `assets/licenses/`).",
        "",
    ]
    with open(os.path.join(OUT_DIR, "NOTICE.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def main():
    if "--download" in sys.argv:
        print("Завантажую джерела (дозвільні ліцензії)…")
        download_sources()
    os.makedirs(OUT_DIR, exist_ok=True)
    blocked = load_blocked()
    print(f"{'мова':6} {'answers':>9} {'allowed':>9}  розподіл answers за довжиною")
    print("-" * 70)
    for lang, cfg in CONFIG.items():
        answers, allowed, swear_found = build_lang(lang, cfg, blocked)
        d = os.path.join(OUT_DIR, lang)
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "answers.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(answers) + "\n")
        with open(os.path.join(d, "allowed.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(allowed) + "\n")
        if swear_found:
            with open(os.path.join(d, "swear.txt"), "w", encoding="utf-8") as f:
                f.write("\n".join(sorted(swear_found)) + "\n")
        by_len = {n: sum(1 for w in answers if len(w) == n) for n in range(MIN_LEN, MAX_LEN + 1)}
        with open(os.path.join(d, "stats.txt"), "w", encoding="utf-8") as f:
            f.write(f"answers: {len(answers)}\nallowed: {len(allowed)}\nswear: {len(swear_found)}\n")
            for n, c in by_len.items():
                f.write(f"len {n}: {c}\n")
        dist = "  ".join(f"{n}:{by_len[n]}" for n in range(MIN_LEN, MAX_LEN + 1))
        print(f"{lang:6} {len(answers):>9} {len(allowed):>9}  {dist}")
    write_notice()
    print("\nГотово. Не забудь: python3 build_all.py (оновлює і прототип)")


if __name__ == "__main__":
    main()

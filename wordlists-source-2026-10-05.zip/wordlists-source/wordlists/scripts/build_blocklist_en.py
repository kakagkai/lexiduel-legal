#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_blocklist_en.py - блокує власні назви в англійському списку відповідей.

Проблема: у частотному корпусі субтитрів є імена (lydia, joyce, david), і вони
потрапляють у «відповіді». Але проста перевірка «чи є слово в списку імен»
викидає й нормальні слова (still, happy, cross, beach) - бо це теж прізвища.

Тому правило таке: блокуємо лише тоді, коли слово
  * є в списку імен,
  * НЕ зустрічається у великій словниковій базі англійських слів,
  * і НЕ входить у 10 000 найуживаніших слів.

Усі решта «слова-близнюки імен» складаємо у names_review.txt для ручної
перевірки носієм (це ~5 хвилин роботи й найнадійніший спосіб).
"""
import os

RAW = "raw"
LISTS = "lists/en"


def load(path):
    if not os.path.exists(path):
        return set()
    with open(path, encoding="utf-8") as f:
        return {w.strip().lower() for w in f if w.strip()}


def main():
    names = load(f"{RAW}/names.txt")
    dictionary = load(f"{RAW}/english_words_alpha.txt")
    common = load(f"{RAW}/google10k.txt")

    counts = {}
    with open(f"{RAW}/count_1w.txt", encoding="utf-8") as f:
        for line in f:
            p = line.split()
            if len(p) == 2:
                try:
                    counts[p[0].lower()] = int(p[1])
                except ValueError:
                    pass

    words = [w.strip() for w in open(f"{LISTS}/answers.txt", encoding="utf-8") if w.strip()]

    # ручний список (імена, які автоматика не спіймала) - головне джерело правок
    manual = set()
    manual_path = f"{LISTS}/blocklist_manual.txt"
    if os.path.exists(manual_path):
        with open(manual_path, encoding="utf-8") as f:
            manual = {w.strip().lower() for w in f if w.strip() and not w.startswith("#")}

    auto = [w for w in words if w in names and w not in dictionary and w not in common]
    blocked = sorted(set(auto) | {w for w in manual if w in set(words)})
    review = [w for w in words if w in names and w not in set(blocked)]

    with open(f"{LISTS}/blocklist.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(blocked) + ("\n" if blocked else ""))

    review.sort(key=lambda w: counts.get(w, 0))
    with open(f"{LISTS}/names_review.txt", "w", encoding="utf-8") as f:
        f.write("# Слова, які збігаються з іменами. Перевір очима (~5 хв).\n")
        f.write("# Якщо це ІМʼЯ - скопіюй слово у blocklist.txt. Якщо звичайне слово - лиши.\n")
        f.write("# Формат: слово<TAB>частота в Google Web Corpus (менше = рідше = ймовірніше імʼя)\n#\n")
        for w in review:
            f.write(f"{w}\t{counts.get(w, 0)}\n")

    print(f"EN: заблоковано {len(blocked)} слів (авто {len(auto)} + ручні {len(manual & set(words))}), на ручну перевірку {len(review)}")
    print("  авто-блок:", ", ".join(auto[:15]))


if __name__ == "__main__":
    main()

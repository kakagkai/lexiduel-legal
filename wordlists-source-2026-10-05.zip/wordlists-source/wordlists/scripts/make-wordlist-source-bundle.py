#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make-wordlist-source-bundle.py - готує архів вихідного коду словників.

## Навіщо це

Чотири з дев'яти джерел словників - під MPL (див. licenses/attribution.json):
LibreOffice dict_uk (MPL-1.1), RLA-ES (MPL-1.1+), dictionary-pl і Dicollecte/
Grammalecte (MPL-2.0).

MPL - це file-level copyleft **із зобов'язанням надати вихідний код
Covered Software**, коли ми поширюємо його у Executable Form. Ми саме це
робимо: build_prototype.py перетворює списки на похідні артефакти
(`answers.txt`, `allowed.txt`) і потім ре-енкодить їх в одну константу
`WORD_ENC` усередині монолітного HTML. Це модифікація.

MPL 2.0, §3.2 вимагає: якщо ми розширюємо Covered Software, ми мусимо
прокласти модифіковані версії під ліцензією MPL, у формі вихідного коду.

Ми це виконуємо. NOTiCE-файл у грі вже пояснює походження; тепер додається
архів, який містить усе необхідне, щобthird-party повторив нашу збірку.

## Що в архіві

    wordlists-source-<date>.zip
      README.md                  - що це і як відтворити
      MANIFEST.txt               - контрольні суми кожного файлу
      source/<lang>/...          - копії вихідних файлів
      build/                     - скрипти, що створюють lists/ з source/
      lists/                     - похідні артефакти (= те, що йде в гру)

Останній пункт навмисний: MPL вимагає надати модифіковані файли, а не лише
оригінали. Саме `lists/` і є модифікованими.

## Запуск

    python3 wordlists/scripts/make-wordlist-source-bundle.py
    # або
    python3 make-wordlist-source-bundle.py --out dist/

Публікацію результату робить людина: архів треба покласти на публічну
сторінку (сторінка «Вихідний код» у Play-лістингу), і її URL вписати в
wordlists/licenses/attribution.json та NOTICE.md.
"""
import argparse
import datetime
import hashlib
import os
import shutil
import sys
import zipfile

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (ValueError, OSError):
        pass

HERE = os.path.dirname(os.path.abspath(__file__))
WL = os.path.abspath(os.path.join(HERE, ".."))

# Каталоги, які треба Ship у архів. `lists/` - це модифіковані артефакти, які
# згідно з MPL 2.0 §3.2 ми мусимо надати; решта - щоб сторонній міг їх
# відтворити.
INCLUDE_DIRS = ["lists"]

# Скрипти, які збирають `lists/` із джерел. Вони лежать у корені wordlists/,
# а не в scripts/ - тому перелічуємо явно, щоб архів був самодостатнім.
# Скрипт, який сам створює архів, теж додаємо: щоб можна було переробити
# архів з архіву.
BUILD_SCRIPTS = [
    "build_all.py",
    "build_wordlists.py",
    "build_blocklists.py",
    "build_blocklist_en.py",
    "build_es_fr.py",
    "build_pt_it_tr.py",
    "build_licenses.py",
    "apply_content_filter.py",
    "apply_cut.py",
    "cut_proposal.py",
    "clean_ua.py",
    "flag_suspicious.py",
    "check_lists.py",
    "freq.py",
]

# Кожен запис - (шлях у репозиторії, шлях у архіві). Простого переліку не
# вистачило: README.md існує і в корені wordlists/, і генерується цим скриптом
# як README самого архіву. Тому чужий файл кладемо під wordlists/, а
# згенерований - у корінь.
INCLUDE_FILES = [
    ("README.md", "wordlists/README.md"),
    ("licenses.js", "wordlists/licenses.js"),
    ("licenses/attribution.json", "wordlists/licenses/attribution.json"),
    ("licenses/NOTICE.md", "wordlists/licenses/NOTICE.md"),
] + [(name, f"wordlists/scripts/{name}") for name in BUILD_SCRIPTS] + [
    (
        "scripts/make-wordlist-source-bundle.py",
        "wordlists/scripts/make-wordlist-source-bundle.py",
    )
]

# Те, що не треба: сирі дампи, рев'ю-файли й кеші.
EXCLUDE_SUFFIXES = (".pyc", ".tmp")
EXCLUDE_NAMES = {"__pycache__", ".git"}
# `suspicious.txt` - це сирий результат аналізу на 259 КБ, а не частина
# постачання. `*_review.txt` - робочі нотатки, які не впливають на збірку.
EXCLUDE_STEMS = {"suspicious"}


def human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.1f} {unit}"
        n /= 1024


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def should_skip(path):
    name = os.path.basename(path)
    if name in EXCLUDE_NAMES:
        return True
    if name.endswith(EXCLUDE_SUFFIXES):
        return True
    stem, _, _ = name.partition(".")
    return stem in EXCLUDE_STEMS


def collect():
    """-> list of (arcname, abspath)"""
    items = []

    for rel, arc in INCLUDE_FILES:
        src = os.path.join(WL, rel)
        if os.path.isfile(src):
            items.append((f"wordlists-source/{arc}", src))
        else:
            print(f"  ⚠️  {rel} не знайдено - пропущено")

    for d in INCLUDE_DIRS:
        base = os.path.join(WL, d)
        if not os.path.isdir(base):
            continue
        for root, dirs, files in os.walk(base):
            dirs[:] = [x for x in dirs if x not in EXCLUDE_NAMES]
            for name in sorted(files):
                src = os.path.join(root, name)
                if should_skip(src):
                    continue
                arc = os.path.relpath(src, WL).replace(os.sep, "/")
                # Не дублювати: файли з INCLUDE_FILES уже додані вище.
                if any(a == f"wordlists-source/{arc}" for a, _ in items):
                    continue
                items.append((f"wordlists-source/{arc}", src))

    return sorted(items)


README = """# LexiDuel word lists - source

This archive is the Corresponding Source for the word lists embedded in
LexiDuel, as required by the Mozilla Public License 2.0, section 3.2.

## Why this exists

Four of the nine dictionary sources are copyleft:

| Language | Source | Licence |
|---|---|---|
| `ua` | LibreOffice `uk_UA` dictionary (`dict_uk`) | MPL-1.1 |
| `es` | RLA-ES / LibreOffice `dictionary-es` | MPL-1.1+ |
| `pl` | dictionary-pl (sjp.pl) | MPL-2.0 |
| `fr` | Dicollecte / Grammalecte | MPL-2.0 |

The game does not ship these lists verbatim. `build_wordlists.py` filters and
reorders them into `answers.txt` and `allowed.txt`, and
`prototype/build_prototype.py` then prefix-encodes those into a single
JavaScript constant inside one self-contained HTML file. That is a
modification, and the MPL requires the modified versions to be available in
source form. They are, in `lists/`.

## What is in here

    lists/                    the MODIFIED files - these are what the game uses
    scripts/                  the scripts that produce lists/ from the originals
    licenses/attribution.json machine-readable attribution
    licenses/                 full licence texts
    README.md                 wordlists/README.md from the repository
    MANIFEST.txt              SHA-256 of every file above

## Reproducing

    python3 scripts/build_all.py          # rebuilds lists/ from scratch

`build_all.py` needs the original upstream word lists, which are fetched or
placed as described in `wordlists/README.md` in the main repository. The
`lists/` directory here is the output, so the game can be rebuilt from this
archive alone if you prefer the exact shipped state over a fresh rebuild.

## Licences

Each source file retains its upstream licence. See `licenses/` for the full
texts and `licenses/attribution.json` for the mapping.

Modified files in `lists/` are distributed under the same licence as their
upstream source. Where an upstream is triple-licensed (the Spanish
dictionary), the MPL terms are the ones relied on here.
"""


def main():
    ap = argparse.ArgumentParser(description="Build the MPL source-offer archive.")
    ap.add_argument("--out", default=os.path.join(WL, "dist"), help="output directory")
    ap.add_argument(
        "--dry-run", action="store_true", help="list what would be archived and stop"
    )
    args = ap.parse_args()

    if not os.path.isdir(os.path.join(WL, "lists")):
        print(f"✗ не знайдено {os.path.join(WL, 'lists')}")
        return 1

    items = collect()
    if not items:
        print("✗ не знайдено жодного файлу для архіву")
        return 1

    manifest_lines = []
    total = 0
    for arc, src in items:
        size = os.path.getsize(src)
        total += size
        manifest_lines.append(f"{sha256(src)}  {size:>9}  {arc}")
        if args.dry_run:
            print(f"  {size:>9}  {arc}")

    if args.dry_run:
        print(f"\n{len(items)} файлів, {human(total)}")
        return 0

    os.makedirs(args.out, exist_ok=True)
    today = datetime.date.today().isoformat()
    zip_name = f"wordlists-source-{today}.zip"
    zip_path = os.path.join(args.out, zip_name)

    manifest = "\n".join(
        [
            "# LexiDuel word list source bundle",
            f"# generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
            "# format: <sha256>  <bytes>  <path in archive>",
            "",
        ]
        + manifest_lines
    )

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        zf.writestr("wordlists-source/README.md", README)
        zf.writestr("wordlists-source/MANIFEST.txt", manifest)
        for arc, src in items:
            zf.write(src, arc)

    size = os.path.getsize(zip_path)
    print(f"✓ {zip_path}")
    print(f"  {len(items)} файлів, {human(total)} -> {human(size)}")

    # Fail loudly if the archive would be useless. A source offer that does not
    # actually contain the modified lists satisfies nobody.
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
    for required in ("wordlists-source/MANIFEST.txt", "wordlists-source/README.md"):
        if required not in names:
            print(f"✗ архів не містить {required}")
            return 1
    if not any(n.startswith("wordlists-source/lists/") for n in names):
        print("✗ архів не містить жодного файлу з lists/ - це не виконує вимогу MPL")
        return 1
    for lang in ("ua", "en", "pl", "de", "ru", "es", "fr", "it", "pt", "tr"):
        if not any(f"wordlists-source/lists/{lang}/" in n for n in names):
            print(f"  ⚠️  мова {lang} відсутня в архіві")

    print("\nНаступний крок (вручну):")
    print("  1. перевір MANIFEST.txt і збережи архів у репозиторій")
    print("  2. опублікуй його на публічній сторінці")
    print("  3. впиши URL у wordlists/licenses/attribution.json (поле sourceUrl)")
    print("     і у wordlists/lists/NOTICE.md")
    print("  4. додай посилання на цю сторінку в ліцензійний екран гри")
    print("     (wordlists/licenses.js) і в Play-лістинг")
    return 0


if __name__ == "__main__":
    sys.exit(main())

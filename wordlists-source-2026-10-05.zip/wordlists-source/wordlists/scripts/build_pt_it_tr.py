#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_pt_it_tr.py - словники для португальської (pt-BR), італійської та
турецької (4-9 літер).

Той самий конвеєр, що й для es/fr (build_es_fr.py), але з трьома новими
мовами й двома важливими відмінностями:

  1. Італійська та португальська мають наголоси, які НЕ можна викинути:
     «città», «perché», «não», «avô». Тому в грі буде додатковий рядок
     клавіатури з цими літерами (як ąćęłńóśźż у польській), а списки
     містять слова тільки з канонічної абетки мови.
  2. Турецька абетка - 29 літер, без q, w, x. Крапкова й некрапкова i
     (i/ı) - різні літери, тому в наборі вони окремо.

Джерела (те саме, що для es/fr):
  порядок за частотою - hermitdave/FrequencyWords (код MIT, дані CC BY-SA 4.0,
                          згенеровано з OpenSubtitles 2018);
  перевірка орфографії - hunspell-словники з wooorm/dictionaries:
      pt - LGPL (Raimundo Moura),
      it - GPL-3 (Andrea Pescetti) - використовується ЛИШЕ локально як
           фільтр, у гру не потрапляє жодного файлу цього словника;
      tr - MIT (Harun Reşit Zafer).
  Словники не постачаються з грою: вони лише відсіюють сміття в списках.

Запуск:  python3 build_pt_it_tr.py [pt|it|tr]
Вихід:   lists/pt/{answers,allowed,blocklist}.txt і так само для it, tr
"""
import os
import re
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = ('https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/'
       'content/2018/{c}/{c}_{kind}.txt')
CACHE = os.path.join(os.path.expanduser('~'), '.cache', 'wd-sources')

LENGTHS = (4, 5, 6, 7, 8, 9)
ANSWERS = 1500          # слів-відповідей на кожну довжину
ALLOWED = 40000         # максимум для вводу (усі довжини разом)

LETTERS = {
    # португальська: a-z + ç + наголошені голосні (ã õ - носові, без них
    # слова не існують, тому вони теж у абетці)
    'pt': set('abcdefghijklmnopqrstuvwxyz'
              'áâãàçéêíóôõú'),
    # італійська: a-z + наголошені (частіше на кінці слова: città, perché)
    'it': set('abcdefghijklmnopqrstuvwxyz'
              'àèéìòù'),
    # турецька: 29 літер, без q w x
    'tr': set('abcçdefgğhıijklmnoöprsştuüvyz'),
}

# Власні назви, міста, англіцизми та лайка, які в субтитрах трапляються
# з малої літери. Списки свідомо короткі: головну роботу роблять словник
# і фільтр англійських слів, а це - страховка. Перед релізом список
# `answers` читають носії (як і для es/fr).
BLOCK = {
    'pt': set('''
joao jose maria pedro luis carlos miguel antonio manuel francisco jesus
paulo rafael daniel lucas gabriel mateus felipe bruno diego thiago
ana laura carmem carmen cristina elena isabel rosa teresa beatriz silvia
patricia monica sandra raquel natalia andreia camila juliana fernanda
mariana larissa amanda letra bruna
brasil portugal lisboa porto braga coimbra aveiro faro setubal
rio janeiro paulo salvador brasilia fortaleza recife manaus curitiba
mexico espanha franca italia grecia russia china japao angola
merda caralho porra puta puto putas putos foder fodase cabrao
buceta pica piroca cu cus caralhos bosta viado boiola corno
idiota imbecil estupido otario babaca otaria
'''.split()),
    'it': set('''
giuseppe giovanni antonio francesco salvatore carmine pasquale mario luigi
angelo vincenzo pietro paolo marco luca andrea stefano alessandro
maria rosa anna giulia francesca chiara sara elena laura martina
paola simona lucia carmela teresa silvia valentina federica alessia
roma milano napoli torino firenze venezia bologna genova palermo catania
italia francia spagna germania russia cina grecia inghilterra
cazzo merda puttana stronzo coglione figa minchia vaffanculo
troia bastardo porco zoccola culo culi cazzata
idiota imbecille stupido cretino scemo
'''.split()),
    'tr': set('''
ahmet mehmet mustafa ali huseyin hasan ibrahim murat osman yusuf
kemal emre burak serkan eren kerem hakan tolga onur
ayse fatma emine hatice zeynep elife meryem sultan zehra
elif merve buse ebru selin gokhan duygu
istanbul ankara izmir bursa antalya adana gaziantep konya trabzon
turkiye almanya fransa italya rusya cin yunanistan
siktir orospu sikeyim amina got sik bok yarak tasak
gerizekali aptal salak mal salaklar embesil
'''.split()),
}

EXTRA_BLOCK = {lang: set('''
mr mrs ok st dr
shit fuck bitch dick cock cunt pussy whore slut crap piss ass
youtube google facebook twitter instagram whatsapp tiktok
'''.split()) for lang in ('pt', 'it', 'tr')}

# Англійські слова, які в субтитрах трапляються з малої літери й проходять
# місцевий словник. Логіка та сама, що в build_es_fr.py: порівнюємо РАНГ
# в англійському та місцевому списках.
EN_URL = ('https://raw.githubusercontent.com/hermitdave/FrequencyWords/'
          'master/content/2018/en/en_50k.txt')
EN_RANK_MAX = 4000
EN_RATIO = 3.0

KEEP_EN = {
    # справжні місцеві слова, що збігаються з англійськими
    'pt': set('''base club gol show top site set ponto frente banda motor
                 social local normal final total legal animal hotel
                 natural central animal geral'''.split()),
    'it': set('''base club show top set fine sale corso corso media nota
                 social local normal final total legal animale hotel
                 centrale naturale generale sale'''.split()),
    'tr': set('''set top role normal final total legal lokal motor
                 taksi doktor otel model pastel'''.split()),
}

HUNSPELL = {
    'pt': 'https://raw.githubusercontent.com/wooorm/dictionaries/main/dictionaries/pt/index',
    'it': 'https://raw.githubusercontent.com/wooorm/dictionaries/main/dictionaries/it/index',
    'tr': 'https://raw.githubusercontent.com/wooorm/dictionaries/main/dictionaries/tr/index',
}


def fetch_spell(code):
    """Словник орфографії (hunspell) для ЛОКАЛЬНОГО фільтрування.

    У гру ці файли не потрапляють: вони лише перевіряють, чи слово
    справді існує. Так у відповіді не проходять імена, міста й англійські
    слова, яких у частотному списку повно.
    """
    os.makedirs(CACHE, exist_ok=True)
    for ext in ('aff', 'dic'):
        path = os.path.join(CACHE, f'{code}_spell.{ext}')
        if not os.path.exists(path):
            url = f'{HUNSPELL[code]}.{ext}'
            print(f'  завантажую {url.rsplit("/", 1)[-1]} ({code})')
            with urllib.request.urlopen(url) as r, open(path, 'wb') as f:
                f.write(r.read())
    try:
        from spylls.hunspell import Dictionary
    except ImportError:
        print('  ⚠️  немає spylls (pip install spylls) - перевірка лише за списком')
        return None
    try:
        return Dictionary.from_files(os.path.join(CACHE, f'{code}_spell'))
    except Exception as e:
        print(f'  ⚠️  словник {code} не завантажився ({e}) - перевірка за списком')
        return None


def spell_ok(spell, words):
    if spell is None:
        return None
    good = set()
    for w in words:
        try:
            if spell.lookup(w):
                good.add(w)
        except Exception:
            pass
    return good


def collect_deep(code, letters, lengths, skip=(), limit=60000):
    """Кандидати з ПОВНОГО частотного списку (не тільки 50k)."""
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, f'{code}_full.txt')
    if not os.path.exists(path):
        url = SRC.format(c=code, kind='full')
        print(f'  завантажую {url.rsplit("/", 1)[-1]}')
        with urllib.request.urlopen(url) as r, open(path, 'wb') as f:
            f.write(r.read())
    out, seen = {n: [] for n in lengths}, set(skip)
    with open(path, encoding='utf-8', errors='ignore') as f:
        for line in f:
            parts = line.split()
            if not parts:
                continue
            w = parts[0].lower()
            n = len(w)
            if n not in out or w in seen or len(out[n]) >= limit:
                continue
            if not all(ch in letters for ch in w) or not w.isalpha():
                continue
            seen.add(w)
            out[n].append(w)
    return out


def fetch(code):
    """50k-список: найуживаніші слова мови в порядку частоти."""
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, f'{code}_50k.txt')
    if not os.path.exists(path):
        url = SRC.format(c=code, kind='50k')
        print(f'  завантажую {url.rsplit("/", 1)[-1]}')
        with urllib.request.urlopen(url) as r, open(path, 'wb') as f:
            f.write(r.read())
    rows = []
    with open(path, encoding='utf-8', errors='ignore') as f:
        for line in f:
            parts = line.split()
            if len(parts) < 2:
                continue
            try:
                rows.append((parts[0].lower(), int(parts[1])))
            except ValueError:
                continue
    rows.sort(key=lambda r: -r[1])
    return rows


def english_drop(lang, words):
    """Які зі слів насправді англійські (за співвідношенням рангів)."""
    cache = os.path.join(CACHE, 'en_50k.txt')
    os.makedirs(CACHE, exist_ok=True)
    if not os.path.exists(cache):
        print('  завантажую en_50k.txt')
        with urllib.request.urlopen(EN_URL) as r, open(cache, 'wb') as f:
            f.write(r.read())
    en_rank = {}
    with open(cache, encoding='utf-8', errors='ignore') as f:
        for i, line in enumerate(f):
            parts = line.split()
            if parts:
                en_rank.setdefault(parts[0].lower(), i + 1)
    lex = set()
    for name in ('answers.txt', 'allowed.txt'):
        path = os.path.join(HERE, 'lists', 'en', name)
        if os.path.exists(path):
            with open(path, encoding='utf-8') as f:
                lex.update(f.read().split())
    keep = KEEP_EN.get(lang, set())
    loc_rank = {}
    with open(os.path.join(CACHE, lang + '_50k.txt'), encoding='utf-8',
              errors='ignore') as f:
        for i, line in enumerate(f):
            parts = line.split()
            if parts:
                loc_rank.setdefault(parts[0].lower(), i + 1)
    drop = set()
    for w in words:
        if w in keep or w not in lex:
            continue
        er = en_rank.get(w, 10 ** 9)
        lr = loc_rank.get(w, 10 ** 9)
        if er < EN_RANK_MAX and lr > EN_RATIO * er:
            drop.add(w)
    return drop


def build(lang):
    rows = fetch(lang)
    spell = fetch_spell(lang)
    letters = LETTERS[lang]
    block = BLOCK[lang] | EXTRA_BLOCK[lang]

    cand, seen = {n: [] for n in LENGTHS}, set()
    for w, _ in rows:
        n = len(w)
        if n not in cand or w in seen:
            continue
        if not all(ch in letters for ch in w) or not w.isalpha():
            continue
        seen.add(w)
        cand[n].append(w)

    deep = collect_deep(lang, letters, LENGTHS, skip=seen)
    words, counts = [], []
    for n in LENGTHS:
        pool = cand[n] + deep.get(n, [])
        ok = spell_ok(spell, pool)
        good = [w for w in pool if ok is None or w in ok]
        if spell is not None:
            print(f'  {lang}: {n} літер - кандидатів {len(pool)}, '
                  f'словник визнав {len(good)}')
        words += good
        counts.append(f'{n}:{len(good)}')
    print(f'  {lang}: «чистих» слів - {len(words)} ({", ".join(counts)})')

    en_drop = english_drop(lang, words)
    print(f'  {lang}: англійських слів у корпусі - {len(en_drop)} '
          f'(з відповідей прибрано, у вводі лишаються)')

    skip_ans = block | en_drop
    answers = []
    for n in LENGTHS:                     # квота на кожну довжину окремо
        answers += [w for w in words if len(w) == n and w not in skip_ans][:ANSWERS]
    aset = set(answers)
    allowed = [w for w in words if w not in aset][:ALLOWED]

    out = os.path.join(HERE, 'lists', lang)
    os.makedirs(out, exist_ok=True)
    for name, data in (('answers.txt', answers), ('allowed.txt', allowed)):
        with open(os.path.join(out, name), 'w', encoding='utf-8') as f:
            f.write('\n'.join(data) + '\n')
    with open(os.path.join(out, 'blocklist.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(sorted(w for w in words if w in block)) + '\n')

    per = {}
    for w in answers:
        per[len(w)] = per.get(len(w), 0) + 1
    print(f'  {lang}: answers {len(answers)} '
          f'({", ".join(f"{n}:{per.get(n, 0)}" for n in LENGTHS)}) · '
          f'allowed {len(allowed)} → lists/{lang}/')


def main():
    argv = [a for a in sys.argv[1:] if not a.startswith('-')]
    langs = argv or ['pt', 'it', 'tr']
    print('Словники PT/IT/TR з FrequencyWords + hunspell-перевірка')
    for lang in langs:
        if lang not in LETTERS:
            print(f'  невідома мова {lang}'); continue
        build(lang)
    print('Готово. Далі: python3 ../prototype/build_prototype.py')
    return 0


if __name__ == '__main__':
    sys.exit(main())

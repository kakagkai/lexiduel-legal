#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_lists.py - перевірка якості словників після збірки.

Запускати після build_wordlists.py. Падає (exit 1), якщо:
  * у відповідях є матюки (їх можна вводити, але загадувати - ніколи);
  * звичайне слово мови не потрапило у відповіді;
  * у відповідях є щось поза довжиною 4-9 або не з літер мови;
  * allowed не містить усіх answers;
  * у списку трапляється службовe слово або очевидне імʼя.

Тут же порівняння з попередньою збіркою (якщо передати теку), щоб було видно,
що змінилось після переходу на дозвільні джерела.
"""

import io
import os
import sys

OUT = "lists"
LANGS = ["en", "de", "pl", "ru", "ua"]

# Тільки слова, які гра справді може загадати: довжина 4-9, без службових.
COMMON = {
    "en": "house water night happy music friend school little people family summer window garden "
          "letter yellow travel market coffee bridge river dream light stone green cloud".split(),
    "de": "wasser nacht musik freund schule familie sommer fenster garten brief gelb reisen markt "
          "kaffee brücke fluss traum licht stein grün wolke stunde blume zimmer".split(),
    "pl": "woda lato okno ogród list żółty podróż rynek kawa most rzeka światło kamień zielony "
          "chmura godzina kwiat pokój muzyka szkoła rodzina".split(),
    "ru": "вода ночь счастье музыка школа семья лето окно письмо жёлтый поездка рынок кофе мост "
          "река свет камень зелёный облако цветок комната".split(),
    "ua": "вода щастя музика школа літо вікно лист жовтий подорож ринок кава міст річка світло "
          "камінь зелений хмара година кімната".split(),
}

# Слова, які НЕ мусять бути відповіддю навіть якщо вони часті
MUST_NOT_ANSWER = {
    "en": "the that with have this from they your will there their about could other these such",
    "de": "der die das dem den des ein eine und aber wenn dass ich du er sie wir ihr nicht auch",
    "pl": "jest były nie tak jak że się to ten ta te tych tym tego oraz albo lub czy ale jednak",
    "ru": "это что как так всё еще уже очень только есть был были быть него неё них ему ей нам",
    "ua": "це що як так все ще вже дуже тільки є був була були бути нього неї них йому їй нам",
}

ALPHA = {
    "en": "abcdefghijklmnopqrstuvwxyz",
    "de": "abcdefghijklmnopqrstuvwxyzäöüß",
    "pl": "aąbcćdeęfghijklłmnńoópqrsśtuvwxyzźż",
    "ru": "абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
    "ua": "абвгґдеєжзиіїйклмнопрстуфхцчшщьюя",
}


def load(path):
    if not os.path.exists(path):
        return []
    with io.open(path, encoding="utf-8") as f:
        return [w.strip() for w in f if w.strip()]


FINAL = {
    "ua": ("ua/answers_clean.txt", "ua/allowed_clean.txt"),
}


def main():
    fails = []
    compare_to = sys.argv[1] if len(sys.argv) > 1 else None
    print(f"{'мова':5} {'answers':>8} {'allowed':>8} {'часті':>7} {'службові':>9}  {'порівняння зі старою збіркою':>28}")
    print("-" * 78)
    for lang in LANGS:
        # українська проходить додаткову чистку (clean_ua.py) → у гру їдуть
        # файли *_clean.txt, тому перевіряти треба саме їх
        a_rel, al_rel = FINAL.get(lang, (f"{lang}/answers.txt", f"{lang}/allowed.txt"))
        answers = load(f"{OUT}/{a_rel}")
        allowed = load(f"{OUT}/{al_rel}")
        swear = load(f"{OUT}/{lang}/swear.txt")
        a, al, sw = set(answers), set(allowed), set(swear)
        alpha = set(ALPHA[lang])

        bad_len = [w for w in a if not (4 <= len(w) <= 9)]
        bad_chars = [w for w in a if not all(c in alpha for c in w)]
        bad_swear = sorted(a & sw)
        bad_service = [w for w in MUST_NOT_ANSWER[lang].split() if w in a]
        missing = [w for w in COMMON[lang] if w not in a]
        missing_allowed = [w for w in COMMON[lang] if w not in al]
        not_in_allowed = [w for w in a if w not in al]
        dupes = len(answers) - len(a)

        if bad_len:
            fails.append(f"{lang}: відповіді поза довжиною 4-9 - {bad_len[:5]}")
        if bad_chars:
            fails.append(f"{lang}: не літери мови - {bad_chars[:5]}")
        if bad_swear:
            fails.append(f"{lang}: матюки у відповідях - {bad_swear[:5]}")
        if bad_service:
            fails.append(f"{lang}: службові слова у відповідях - {bad_service[:5]}")
        if missing:
            fails.append(f"{lang}: немає звичайних слів у відповідях - {', '.join(missing)}")
        if missing_allowed:
            fails.append(f"{lang}: немає звичайних слів у allowed - {', '.join(missing_allowed)}")
        if not_in_allowed:
            fails.append(f"{lang}: {len(not_in_allowed)} відповідей відсутні в allowed")
        if dupes:
            fails.append(f"{lang}: дублікати у списку ({dupes})")
        if len(a) < 3000:
            fails.append(f"{lang}: замало відповідей ({len(a)}) - гра закінчиться словами")

        cmp_txt = ""
        if compare_to:
            old = set(load(f"{compare_to}/{lang}/answers.txt"))
            if old:
                inter = len(a & old)
                cmp_txt = f"+{len(a - old)} нових, −{len(old - a)} старих, спільних {100 * inter // max(1, len(a))}%"

        print(f"{lang:5} {len(a):>8} {len(al):>8} {len(COMMON[lang]) - len(missing):>4}/{len(COMMON[lang])} "
              f"{len(MUST_NOT_ANSWER[lang].split()) - len(bad_service):>5}/{len(MUST_NOT_ANSWER[lang].split())}  {cmp_txt:>28}")

    # ── українська: у відповідях не має бути російських слів ──
    # (корпус субтитрів і словник LibreOffice містять російські слова -
    #  тому потрібен окремий курований список lists/ua/russisms_manual.txt)
    rp = "lists/ua/russisms_manual.txt"
    if os.path.exists(rp):
        russ = set()
        for line in io.open(rp, encoding="utf-8"):
            line = line.split("#")[0].strip()
            if line:
                russ.update(line.split())
        ua = {w.strip() for w in io.open("lists/ua/answers_clean.txt", encoding="utf-8") if w.strip()} \
            if os.path.exists("lists/ua/answers_clean.txt") else set()
        hits = sorted(ua & russ)
        if hits:
            fails.append(f"ua: російські слова у відповідях ({len(hits)}): {' '.join(hits[:15])}")
        else:
            print(f"{'ua':5} {'-':>8} {'-':>8}  російських слів у відповідях: 0 "
                  f"(список із {len(russ)} слів)")

    print("-" * 78)
    if fails:
        print("❌ ПРОБЛЕМИ:")
        for f in fails:
            print("   ·", f)
        sys.exit(1)
    print("✅ СЛОВНИКИ ЯКІСНІ (дозвільні ліцензії, часті слова на місці, матюки - лише для введення)")


if __name__ == "__main__":
    main()

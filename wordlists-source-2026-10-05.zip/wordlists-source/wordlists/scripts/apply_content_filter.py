#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
apply_content_filter.py - застосовує контент-фільтр (swear/<мова>.txt) до
готових списків у lists/, не перераховуючи словники з нуля.

Навіщо окремий крок: повний перерахунок (build_wordlists.py) потребує
кешу частот FrequencyWords (~/.cache/wd-sources), а він важкий і не завжди
під рукою. Сам фільтр від частот не залежить - це просто «викинути ці
слова з відповідей». Тому після правки swear-списків достатньо цього кроку.

Правила:
  * слово зі swear-списку прибирається з answers.txt;
  * якщо його немає в allowed.txt - додається, щоб гравець міг його ввести
    (гра має приймати будь-який здогад, інакше здається, що словник зламано);
  * файли пишуться лише після всіх перевірок, порядок слів зберігається.

Запуск:  python3 apply_content_filter.py
Вихід:   lists/<мова>/{answers,allowed}.txt оновлені + звіт на екрані.
"""

import io
import os

LANGS = ["ua", "ru", "en", "pl", "de"]
HERE = os.path.dirname(os.path.abspath(__file__))


def read_list(path):
    if not os.path.exists(path):
        return []
    with io.open(path, encoding="utf-8") as f:
        return f.read().split()


def write_list(path, items):
    """Одне слово на рядок - саме так читають усі інші скрипти конвеєра."""
    with io.open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(items) + "\n")


def main():
    total_removed = 0
    for lang in LANGS:
        swear_path = os.path.join(HERE, "swear", f"{lang}.txt")
        if not os.path.exists(swear_path):
            print(f"  ⚠️  немає {swear_path} - {lang} без фільтра")
            continue
        with io.open(swear_path, encoding="utf-8") as f:
            swear = {ln.strip() for ln in f if ln.strip() and not ln.startswith("#")}

        # Українська проходить додаткову чистку від русизмів → у гру їдуть
        # файли *_clean.txt. Фільтрувати треба САМЕ їх, інакше правка не доїде.
        base = "answers_clean.txt" if lang == "ua" else "answers.txt"
        base_allow = "allowed_clean.txt" if lang == "ua" else "allowed.txt"
        ans_path = os.path.join(HERE, "lists", lang, base)
        allow_path = os.path.join(HERE, "lists", lang, base_allow)
        if lang == "ua":
            # підтримуємо в синхроні і проміжний файл, щоб check_lists не сварився
            write_list(os.path.join(HERE, "lists", lang, "answers.txt"),
                       [w for w in read_list(os.path.join(HERE, "lists", lang, "answers.txt")) if w not in swear] or
                       read_list(ans_path))
        answers = read_list(ans_path)
        allowed = read_list(allow_path)
        if not answers or not allowed:
            print(f"  ⚠️  немає списків для {lang} - пропускаю")
            continue

        removed = [w for w in answers if w in swear]
        if not removed:
            print(f"  {lang}: нічого прибирати (фільтр {len(swear)} слів)")
            continue

        answers_new = [w for w in answers if w not in swear]
        allow_set = set(allowed)
        added = [w for w in removed if w not in allow_set]

        # Слова коротші за 4 літери у відповідях не бувають, тож фільтр
        # не має ламати розмір пулів. Перевіряємо, що пул не спорожнів.
        for n in (4, 5, 6, 7, 8, 9):
            left = sum(1 for w in answers_new if len(w) == n)
            if left < 60:
                raise SystemExit(f"{lang}: після фільтра лишилось {left} слів довжини {n} - "
                                 f"це зламає гру, перевір swear-список")

        write_list(ans_path, answers_new)
        if added:
            write_list(allow_path, allowed + added)

        total_removed += len(removed)
        print(f"  {lang}: прибрано з відповідей {len(removed)} "
              f"({', '.join(removed[:8])}{'…' if len(removed) > 8 else ''})"
              f"{f', у allowed додано {len(added)}' if added else ''}")

    print(f"\n✅ контент-фільтр застосовано: прибрано {total_removed} слів-відповідей "
          f"(усі лишились вводимими)")


if __name__ == "__main__":
    main()

# LexiDuel word lists - source

This archive is the Corresponding Source for the word lists embedded in
LexiDuel, as required by the Mozilla Public License 2.0, section 3.2.

## Why this exists

Four of the nine dictionary sources are copyleft:

| Language | Source | Licence |
|---|---|---|
| `ua` | LibreOffice `uk_UA` dictionary (`dict_uk`) | MPL-1.1 |
| `es` | RLA-ES / LibreOffice `dictionary-es` | MPL-1.1+ |
| `pl` | dictionary-pl (sjp.pl) | MPL-2.0 |
| `fr` | Dicollecte / Grammalecte | MPL-2.0 |

The game does not ship these lists verbatim. `build_wordlists.py` filters and
reorders them into `answers.txt` and `allowed.txt`, and
`prototype/build_prototype.py` then prefix-encodes those into a single
JavaScript constant inside one self-contained HTML file. That is a
modification, and the MPL requires the modified versions to be available in
source form. They are, in `lists/`.

## What is in here

    lists/                    the MODIFIED files - these are what the game uses
    scripts/                  the scripts that produce lists/ from the originals
    licenses/attribution.json machine-readable attribution
    licenses/                 full licence texts
    README.md                 wordlists/README.md from the repository
    MANIFEST.txt              SHA-256 of every file above

## Reproducing

    python3 scripts/build_all.py          # rebuilds lists/ from scratch

`build_all.py` needs the original upstream word lists, which are fetched or
placed as described in `wordlists/README.md` in the main repository. The
`lists/` directory here is the output, so the game can be rebuilt from this
archive alone if you prefer the exact shipped state over a fresh rebuild.

## Licences

Each source file retains its upstream licence. See `licenses/` for the full
texts and `licenses/attribution.json` for the mapping.

Modified files in `lists/` are distributed under the same licence as their
upstream source. Where an upstream is triple-licensed (the Spanish
dictionary), the MPL terms are the ones relied on here.

# Джерела словників і ліцензії

Цей файл згенеровано `build_wordlists.py`. Списки слів у застосунку
Lexiduel зібрані **лише з дозвільних джерел** - жодного GPL,
жодного share-alike. Атрибуція нижче дублюється в самому застосунку
на екрані «Ліцензії та подяки».

## en
* FrequencyWords (OpenSubtitles) - MIT - https://github.com/hermitdave/FrequencyWords
* SCOWL / dictionary-en - MIT AND BSD - https://github.com/wooorm/dictionaries/tree/main/dictionaries/en

## de
* FrequencyWords (OpenSubtitles) - MIT - https://github.com/hermitdave/FrequencyWords
* spielwoerter - CC0 1.0 - https://github.com/marekventur/spielwoerter

## pl
* FrequencyWords (OpenSubtitles) - MIT - https://github.com/hermitdave/FrequencyWords
* dictionary-pl (sjp.pl) - MPL-2.0 - https://github.com/wooorm/dictionaries/tree/main/dictionaries/pl

## ru
* FrequencyWords (OpenSubtitles) - MIT - https://github.com/hermitdave/FrequencyWords
* dictionary-ru - BSD-3-Clause - https://github.com/wooorm/dictionaries/tree/main/dictionaries/ru

## ua
* FrequencyWords (OpenSubtitles) - MIT - https://github.com/hermitdave/FrequencyWords
* LibreOffice uk_UA (dict_uk) - MPL-1.1 - https://github.com/LibreOffice/dictionaries/tree/master/uk_UA

## Машинозчитуваний перелік

Той самий перелік у JSON (з нього будується екран «Ліцензії та подяки»
в застосунку): `licenses/attribution.json`, збірка - `build_licenses.py`.

## Повні тексти ліцензій

Файли ліцензій лежать у `wordlists/licenses/` і копіюються в застосунок
(Flutter: `assets/licenses/`).

